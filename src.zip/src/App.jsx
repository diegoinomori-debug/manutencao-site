import React, { useEffect, useMemo, useState } from "react";
import * as XLSX from "xlsx";
import Tesseract from "tesseract.js";

import {
  Plus,
  Trash2,
  Search,
  Home,
  Wrench,
  CalendarDays,
  FileText,
  Package,
  Hammer,
  Bot,
  Save,
  X,
} from "lucide-react";
import "./index.css";
import { db } from "./firebase";

import {
  collection,
  addDoc,
  getDocs,
  deleteDoc,
  doc,
  updateDoc,
} from "firebase/firestore";

function toLocalDateText(date = new Date()) {
  const d = date instanceof Date ? date : new Date(date);
  if (Number.isNaN(d.getTime())) return "";
  const yyyy = d.getFullYear();
  const mm = String(d.getMonth() + 1).padStart(2, "0");
  const dd = String(d.getDate()).padStart(2, "0");
  return `${yyyy}-${mm}-${dd}`;
}

function parseLocalDate(dateString) {
  if (!dateString) return null;
  if (dateString instanceof Date && !Number.isNaN(dateString.getTime())) {
    const d = new Date(dateString);
    d.setHours(0, 0, 0, 0);
    return d;
  }

  const text = String(dateString).trim().replace(/\//g, "-");
  const match = text.match(/^(\d{4})-(\d{1,2})-(\d{1,2})/);
  if (!match) return null;

  const d = new Date(Number(match[1]), Number(match[2]) - 1, Number(match[3]));
  d.setHours(0, 0, 0, 0);
  return d;
}

const today = parseLocalDate(toLocalDateText());

function addDays(dateString, days) {
  if (!dateString || days === undefined || days === null || days === "") return "";
  const date = parseLocalDate(dateString);
  if (!date) return "";
  date.setDate(date.getDate() + Number(days));
  return toLocalDateText(date);
}

function diffDays(dateString) {
  if (!dateString) return "";
  const target = parseLocalDate(dateString);
  if (!target) return "";
  return Math.ceil((target - today) / (1000 * 60 * 60 * 24));
}

function getStatus(daysLeft) {
  if (daysLeft === "") return "未入力";
  if (daysLeft < 0) return "交換超過";
  if (daysLeft <= 7) return "交換間近";
  return "正常";
}

function todayText() {
  return toLocalDateText();
}

function createBlankReport() {
  return {
    reportTitle: "保全作業報告書",
    reportType: "保全作業報告書",
    createdAt: todayText(),
    maintenanceType: "CM",

    troubleDateTime: "",
    workStartDateTime: "",
    workEndDateTime: "",
    productionStartDateTime: "",
    stopExclusionHours: 0,
    stopExclusionTime: "0",
    functionDownRate: 100,
    stopTimeHours: 0,

    groupName: "",
    lineName: "",
    equipment: "",

    phenomenon: "",
    troublePoint: "",
    why1: "",
    why2: "",
    why3: "",
    why4: "",
    why5: "",
    action: "",
    linkUrl: "",

    recurrenceCategory: "必要",
    recurrenceStatus: "未実施",
    recurrencePrevention: "",
    outflowPrevention: "",
    changeRank: "",
    fpInspection: "点検不要",

    worker: "",
    workerCount: 1,
    laborRate: 3000,
    laborHours: 0,
    laborCost: 0,

    replacedPart: "",
    stockQty: "",
    partQty1: "",
    partUnitPrice1: "",
    partName1: "",
    partQty2: "",
    partUnitPrice2: "",
    partName2: "",
    partQty3: "",
    partUnitPrice3: "",
    partName3: "",
    partsCost: 0,
    totalCost: 0,

    approvalStatus: "下書き",
    dbInputBy: "",
    approvedBy: "",
    inspectedBy: "",
    createdBy: "",
    dbInputDate: "",
    approvedDate: "",
    inspectedDate: "",
    reportCreatedDate: todayText(),

    beforeImage: "",
    afterImage: "",
    image: "",
    note: "",
  };
}

function createBlankPlannedWork(date = "") {
  return {
    date: date || todayText(),
    endDate: "",
    title: "",
    equipment: "",
    purpose: "",
    detail: "",
    owner: "",
    status: "計画中",
    progress: 0,
    risk: "",
    note: "",
    image: "",
  };
}

function createBlankCalendarEvent(date = "") {
  return {
    date: date || todayText(),
    time: "",
    title: "",
    detail: "",
    owner: "",
    importance: "通常",
    category: "定期保全",
    image: "",
  };
}

function containsAll(text, keywords) {
  const target = String(text || "").toLowerCase();
  return keywords.every((keyword) => target.includes(keyword));
}


function normalizeDateTime(value) {
  if (!value) return "";
  if (value instanceof Date && !isNaN(value.getTime())) {
    const yyyy = value.getFullYear();
    const mm = String(value.getMonth() + 1).padStart(2, "0");
    const dd = String(value.getDate()).padStart(2, "0");
    const hh = String(value.getHours()).padStart(2, "0");
    const mi = String(value.getMinutes()).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}T${hh}:${mi}`;
  }

  const text = String(value).trim();
  if (!text) return "";
  if (/^\d{4}[-/]\d{1,2}[-/]\d{1,2}\s+\d{1,2}:\d{2}/.test(text)) {
    return text.replace(/\//g, "-").replace(" ", "T").slice(0, 16);
  }
  if (/^\d{4}[-/]\d{1,2}[-/]\d{1,2}$/.test(text)) {
    return text.replace(/\//g, "-") + "T00:00";
  }
  return text.replace(/\//g, "-").replace(" ", "T").slice(0, 16);
}

function normalizeDateOnly(value) {
  const dt = normalizeDateTime(value);
  return dt ? dt.slice(0, 10) : "";
}

function toNumber(value, fallback = 0) {
  if (value === undefined || value === null || value === "") return fallback;
  const normalized = String(value).replace(/,/g, "").replace(/円/g, "").replace(/H/g, "").replace(/%/g, "").trim();
  const num = Number(normalized);
  return Number.isFinite(num) ? num : fallback;
}

function hoursBetween(startValue, endValue) {
  if (!startValue || !endValue) return 0;
  const start = new Date(startValue);
  const end = new Date(endValue);
  if (isNaN(start.getTime()) || isNaN(end.getTime())) return 0;
  return Math.max(0, (end - start) / 3600000);
}

function calculateReport(report = {}) {
  const stopExclusionHours = toNumber(report.stopExclusionHours ?? report.stopExclusionTime, 0);
  const functionDownRateRaw = toNumber(report.functionDownRate, 100);
  const functionDownRate = functionDownRateRaw <= 1 ? functionDownRateRaw : functionDownRateRaw / 100;

  const startForStop = report.troubleDateTime || report.workStartDateTime;
  const endForStop = report.productionStartDateTime || report.workEndDateTime;
  const stopTimeHours = Math.max(0, (hoursBetween(startForStop, endForStop) - stopExclusionHours) * functionDownRate);

  const workerCount = toNumber(report.workerCount, 1);
  const laborRate = toNumber(report.laborRate, 3000);
  const laborBaseHours = Math.max(0, hoursBetween(report.workStartDateTime, report.workEndDateTime) - stopExclusionHours);
  const laborHours = laborBaseHours * workerCount;
  const laborCost = Math.round(laborHours * laborRate);

  const partAmount1 = toNumber(report.partQty1, 0) * toNumber(report.partUnitPrice1, 0);
  const partAmount2 = toNumber(report.partQty2, 0) * toNumber(report.partUnitPrice2, 0);
  const partAmount3 = toNumber(report.partQty3, 0) * toNumber(report.partUnitPrice3, 0);
  const partsCost = Math.round(partAmount1 + partAmount2 + partAmount3 + toNumber(report.partsCostManual, 0));
  const totalCost = Math.round(laborCost + partsCost);

  return {
    stopExclusionHours,
    functionDownRate: functionDownRateRaw,
    stopTimeHours: Number(stopTimeHours.toFixed(2)),
    laborHours: Number(laborHours.toFixed(2)),
    laborCost,
    partAmount1,
    partAmount2,
    partAmount3,
    partsCost,
    totalCost,
  };
}

function reportStatusColor(status) {
  if (status === "承認済み") return "#dcfce7";
  if (status === "承認待ち") return "#fef3c7";
  if (status === "点検待ち") return "#dbeafe";
  if (status === "差戻し") return "#fee2e2";
  return "#f1f5f9";
}


const PROFESSIONAL_RESPONSIVE_CSS = `
/* ===== MIYAMA Professional Responsive UI Patch ===== */
:root {
  --miyama-blue:#2563eb;
  --miyama-blue-dark:#1d4ed8;
  --miyama-bg:#f6f8fb;
  --miyama-card:#ffffff;
  --miyama-border:#dbe3ef;
  --miyama-text:#0f172a;
  --miyama-muted:#64748b;
  --miyama-danger:#dc2626;
  --miyama-warn:#f59e0b;
  --miyama-ok:#16a34a;
  --safe-bottom: env(safe-area-inset-bottom, 0px);
}


.moneyText {
  display:inline-block;
  white-space:nowrap !important;
  word-break:keep-all !important;
  overflow-wrap:normal !important;
  font-variant-numeric:tabular-nums;
}
.card .moneyText {
  font-size:clamp(24px, 2.4vw, 34px) !important;
  line-height:1.12 !important;
}
.card {
  overflow:hidden;
}
@media (max-width: 520px) {
  .card .moneyText { font-size:22px !important; }
}

html, body, #root { width:100%; min-height:100%; overflow-x:hidden; }
body { background:#f6f8fb !important; color:var(--miyama-text); -webkit-text-size-adjust:100%; }
.page { width:100%; max-width:100vw; overflow-x:hidden; padding:20px clamp(12px, 2vw, 28px) 80px !important; }
.container { width:100%; max-width:1560px !important; }

.tableWrap, .calendarEditCard, .card {
  background:rgba(255,255,255,.96) !important;
  border:1px solid rgba(148,163,184,.28) !important;
  box-shadow:0 12px 34px rgba(15,23,42,.08) !important;
}
.tableWrap { border-radius:22px !important; padding:clamp(14px,2vw,22px) !important; overflow-x:auto; }
.calendarEditCard { border-radius:18px !important; }

.header { align-items:flex-start !important; }
.header h1, .header h2, .header h3 { line-height:1.25 !important; word-break:keep-all; overflow-wrap:anywhere; }
p, h1, h2, h3, strong, span, label, div { word-break:normal; overflow-wrap:anywhere; }

input, select, textarea {
  border:1px solid #cbd5e1 !important;
  border-radius:14px !important;
  min-height:44px;
  line-height:1.45;
  background:#fff !important;
}
textarea { min-height:96px !important; white-space:pre-wrap; }

.primaryButton, .deleteButton {
  border-radius:14px !important;
  min-height:44px !important;
  white-space:normal !important;
  text-align:center;
  justify-content:center;
}
.primaryButton { background:linear-gradient(135deg,#2563eb,#1d4ed8) !important; }
.deleteButton { background:#fee2e2 !important; color:#b91c1c !important; }

.tabs {
  position:sticky;
  top:0;
  z-index:50;
  padding:10px 0 12px;
  background:linear-gradient(180deg,rgba(246,248,251,.98),rgba(246,248,251,.86));
  backdrop-filter:blur(12px);
  border-bottom:1px solid rgba(148,163,184,.18);
}
.tabs button { white-space:nowrap; min-height:46px; }

.cards { grid-template-columns:repeat(auto-fit,minmax(180px,1fr)) !important; }
.card { min-width:0; }
.card strong { overflow-wrap:anywhere; line-height:1.1; }
.reportGrid { grid-template-columns:repeat(auto-fit,minmax(240px,1fr)) !important; }

.calendarLayout { grid-template-columns:minmax(0,1.4fr) minmax(320px,.8fr) !important; }
.calendarDay { min-width:0; }
.calendarEventTag { max-width:100%; }

/* Inline grid overrides from App.jsx */
div[style*="grid-template-columns: 320px 1fr"],
div[style*="grid-template-columns: 1fr 420px"],
div[style*="grid-template-columns: repeat(4, 1fr)"],
div[style*="grid-template-columns: repeat(3, 1fr)"] {
  min-width:0;
}

/* Better desktop cards for spare parts */
div[style*="grid-template-columns: 320px 1fr"] h2 { overflow-wrap:anywhere !important; }
div[style*="grid-template-columns: 320px 1fr"] input,
div[style*="grid-template-columns: 320px 1fr"] textarea,
div[style*="grid-template-columns: 320px 1fr"] select { max-width:100%; }

/* Modals */
.modalBackdrop { padding:16px !important; }
.modalCard { width:min(980px,96vw) !important; max-height:92vh; overflow:auto; border-radius:22px !important; }

@media (min-width: 901px) {
  .tabs { overflow-x:auto; flex-wrap:nowrap !important; }
  .tabs::-webkit-scrollbar { height:6px; }
  .tabs::-webkit-scrollbar-thumb { background:#cbd5e1; border-radius:999px; }
}

@media (max-width: 900px) {
  .page { padding:10px 10px calc(90px + var(--safe-bottom)) !important; }
  .container { max-width:100% !important; }
  .page::before { font-size:42px !important; line-height:96px !important; letter-spacing:22px !important; opacity:.035 !important; }

  .tabs {
    display:flex !important;
    flex-wrap:nowrap !important;
    overflow-x:auto !important;
    gap:8px !important;
    margin:0 -10px 14px !important;
    padding:8px 10px 10px !important;
    scroll-snap-type:x proximity;
    -webkit-overflow-scrolling:touch;
  }
  .tabs button {
    flex:0 0 auto !important;
    min-width:118px !important;
    padding:10px 12px !important;
    font-size:13px !important;
    scroll-snap-align:start;
  }

  .header { flex-direction:column !important; gap:10px !important; margin-bottom:12px !important; }
  .header > div, .header > button, .header > label { width:100%; }
  .header h1 { font-size:26px !important; }
  .header h2 { font-size:22px !important; }
  .header p, .tableWrap p { font-size:14px !important; }

  .tableWrap { border-radius:18px !important; margin-bottom:14px !important; padding:14px !important; }
  .calendarEditCard { padding:14px !important; }
  .reportGrid { grid-template-columns:1fr !important; gap:10px !important; }
  .cards { grid-template-columns:1fr 1fr !important; gap:10px !important; }
  .card { padding:14px !important; border-radius:16px !important; }
  .card strong { font-size:24px !important; }

  input, select, textarea { font-size:16px !important; width:100% !important; max-width:100% !important; }
  .primaryButton, .deleteButton { width:auto; max-width:100%; font-size:14px !important; padding:10px 12px !important; }

  /* Spare parts product card: one column on mobile */
  div[style*="grid-template-columns: 320px 1fr"] {
    display:grid !important;
    grid-template-columns:1fr !important;
    gap:14px !important;
    padding:14px !important;
    margin-bottom:14px !important;
    overflow:hidden !important;
  }
  div[style*="grid-template-columns: 320px 1fr"] > div:first-child {
    width:100% !important;
    text-align:center !important;
  }
  div[style*="grid-template-columns: 320px 1fr"] img,
  div[style*="width: 300px"][style*="height: 300px"] {
    width:min(190px, 72vw) !important;
    height:min(190px, 72vw) !important;
    margin:0 auto !important;
    display:flex !important;
  }
  div[style*="grid-template-columns: 320px 1fr"] h2 {
    font-size:22px !important;
    line-height:1.35 !important;
    margin-top:4px !important;
  }
  div[style*="text-align: right"] { text-align:left !important; }

  /* Approval/header area from report form */
  div[style*="grid-template-columns: 1fr 420px"] {
    display:grid !important;
    grid-template-columns:1fr !important;
  }
  div[style*="grid-template-columns: repeat(4, 1fr)"] {
    display:grid !important;
    grid-template-columns:1fr 1fr !important;
    border-left:0 !important;
  }
  div[style*="grid-template-columns: repeat(4, 1fr)"] > div {
    min-height:auto !important;
    border:1px solid #dbe3ef !important;
    border-radius:14px !important;
    margin:6px !important;
    background:#f8fafc !important;
  }

  /* Calendar */
  .calendarLayout { grid-template-columns:1fr !important; }
  .calendarTop { gap:8px !important; flex-wrap:wrap !important; }
  .calendarTop h2 { width:100%; text-align:center; font-size:20px !important; order:-1; }
  .calendarWeek, .calendarGrid { grid-template-columns:repeat(7,minmax(0,1fr)) !important; }
  .calendarWeek div { font-size:11px !important; padding:6px 2px !important; }
  .calendarGrid { gap:4px !important; }
  .calendarDay { min-height:66px !important; padding:5px !important; border-radius:10px !important; font-size:12px !important; }
  .calendarEventTag { font-size:9px !important; padding:2px 3px !important; }

  /* Tables stay usable, but don't break page width */
  table { min-width:760px !important; }
  th, td { padding:8px !important; }
}

@media (max-width: 520px) {
  .page { padding-left:8px !important; padding-right:8px !important; }
  .tabs { margin-left:-8px !important; margin-right:-8px !important; }
  .cards { grid-template-columns:1fr !important; }
  .tableWrap { padding:12px !important; }
  .card strong { font-size:22px !important; }

  div[style*="grid-template-columns: repeat(4, 1fr)"] { grid-template-columns:1fr !important; }

  /* Button groups become readable */
  div[style*="display: flex"][style*="gap: 10px"] {
    gap:8px !important;
  }
  div[style*="display: flex"][style*="gap: 10px"] > button,
  div[style*="display: flex"][style*="gap: 10px"] > label {
    flex:1 1 auto;
  }

  .calendarDay { min-height:58px !important; }
  .calendarEventList { display:none !important; }
}

/* ===== Spectacular calendar redesign ===== */
.calendarDay {
  position:relative;
  overflow:hidden;
  display:flex;
  flex-direction:column;
  gap:6px;
}
.calendarDay.emptyDay {
  background:transparent !important;
  border:1px dashed rgba(148,163,184,.18) !important;
  box-shadow:none !important;
  cursor:default !important;
}
.calendarDayHeader {
  display:flex;
  align-items:center;
  justify-content:space-between;
  gap:4px;
  width:100%;
}
.calendarDayNumber {
  display:inline-flex;
  align-items:center;
  justify-content:center;
  min-width:28px;
  height:28px;
  border-radius:999px;
  font-weight:900;
  font-size:15px;
  color:#0f172a;
  background:#f8fafc;
}
.selectedDay .calendarDayNumber {
  color:#fff;
  background:#2563eb;
}
.calendarSummaryPills {
  display:flex;
  gap:4px;
  flex-wrap:wrap;
  align-items:center;
  width:100%;
}
.calendarSummaryPill {
  display:inline-flex;
  align-items:center;
  gap:3px;
  padding:3px 6px;
  border-radius:999px;
  background:#eff6ff;
  color:#1d4ed8;
  font-weight:800;
  font-size:11px;
  line-height:1.1;
  border:1px solid #bfdbfe;
}
.calendarSummaryPill.urgentPill {
  background:#fee2e2;
  color:#b91c1c;
  border-color:#fecaca;
}
.calendarMiniText {
  width:100%;
  display:block;
  font-size:11px;
  color:#475569;
  line-height:1.25;
  white-space:nowrap;
  overflow:hidden;
  text-overflow:ellipsis;
  background:#f8fafc;
  border:1px solid #e2e8f0;
  border-radius:8px;
  padding:4px 6px;
}
.selectedEventsHeader {
  display:flex;
  justify-content:space-between;
  align-items:center;
  gap:10px;
  flex-wrap:wrap;
  margin-top:18px;
  padding:12px;
  border-radius:16px;
  background:linear-gradient(135deg,#eff6ff,#ffffff);
  border:1px solid #bfdbfe;
}
.selectedEventCards {
  display:grid;
  grid-template-columns:repeat(auto-fit,minmax(280px,1fr));
  gap:12px;
  margin-top:12px;
}
.eventRow {
  border-radius:16px !important;
  border:1px solid #dbe3ef !important;
  background:#fff !important;
  box-shadow:0 10px 24px rgba(15,23,42,.06) !important;
  padding:14px !important;
}
.eventRowTitle {
  font-size:16px;
  line-height:1.35;
  margin-bottom:8px;
  color:#0f172a;
}
.eventMetaLine {
  display:flex;
  gap:8px;
  flex-wrap:wrap;
  margin:8px 0;
}
.eventMetaBadge {
  display:inline-flex;
  align-items:center;
  padding:4px 8px;
  border-radius:999px;
  background:#f1f5f9;
  color:#334155;
  font-size:12px;
  font-weight:700;
}
.eventDetailText {
  color:#475569;
  font-size:13px;
  line-height:1.6;
  white-space:pre-wrap;
}
@media (max-width: 520px) {
  .calendarGrid { gap:6px !important; }
  .calendarDay { min-height:78px !important; padding:6px !important; }
  .calendarDayNumber { min-width:24px; height:24px; font-size:13px; }
  .eventCount { display:none !important; }
  .calendarEventList { display:block !important; }
  .calendarEventTag { display:none !important; }
  .calendarMiniText { display:none; }
  .calendarSummaryPill { font-size:10px; padding:3px 5px; }
  .selectedEventCards { grid-template-columns:1fr; }
}

.compareGraphGrid { grid-template-columns: 280px 1fr 130px !important; }
@media (max-width: 760px) {
  .compareGraphGrid {
    grid-template-columns: 1fr !important;
    gap: 6px !important;
  }
  .compareGraphGrid strong {
    margin-bottom: 10px;
  }
}

`;

export default function App() {
  const [parts, setParts] = useState([]);
  const [calendarEvents, setCalendarEvents] = useState([]);
  const [reports, setReports] = useState([]);
  const [plannedWorks, setPlannedWorks] = useState([]);

  const [page, setPage] = useState("home");
  const [globalSearch, setGlobalSearch] = useState("");
  const [reportSearch, setReportSearch] = useState("");
  const [spareSearch, setSpareSearch] = useState("");
  const [maintenanceSearch, setMaintenanceSearch] = useState("");
  const [maintenanceTypeFilter, setMaintenanceTypeFilter] = useState("全て");
  const [maintenanceSort, setMaintenanceSort] = useState("urgent");
  const [spareAiInput, setSpareAiInput] = useState("");
  const [spareAiPreview, setSpareAiPreview] = useState(null);
  const [sparePhotoImage, setSparePhotoImage] = useState("");
  const [sparePhotoOcrText, setSparePhotoOcrText] = useState("");
  const [sparePhotoLoading, setSparePhotoLoading] = useState(false);
  const [ocrCandidates, setOcrCandidates] = useState([]);
  const [aiSearch, setAiSearch] = useState("");
  const [aiAnswer, setAiAnswer] = useState("");
  const [aiLevel, setAiLevel] = useState("");
  const [autoReportInput, setAutoReportInput] = useState("");
  const [analyticsPeriod, setAnalyticsPeriod] = useState("month");
  const [analyticsBaseDate, setAnalyticsBaseDate] = useState(todayText());

  const [newReport, setNewReport] = useState(null);
  const [newCalendarEvent, setNewCalendarEvent] = useState(null);
  const [editingCalendarEventId, setEditingCalendarEventId] = useState(null);
  const [newPlannedWork, setNewPlannedWork] = useState(null);

  const [calendarMonth, setCalendarMonth] = useState(new Date());
  const [selectedDate, setSelectedDate] = useState(todayText());

  const [openSections, setOpenSections] = useState({
    basic: true,
    trouble: true,
    why: false,
    cost: false,
    other: false,
  });

  useEffect(() => {
    loadAll();
  }, []);

  async function loadAll() {
    await Promise.all([
      loadParts(),
      loadCalendar(),
      loadReports(),
      loadPlannedWorks(),
    ]);
  }

  async function loadParts() {
    const snap = await getDocs(collection(db, "parts"));
    setParts(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
  }

  async function loadCalendar() {
    const snap = await getDocs(collection(db, "calendar"));
    setCalendarEvents(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
  }

  async function loadReports() {
    const snap = await getDocs(collection(db, "maintenanceReports"));
    setReports(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
  }

  async function loadPlannedWorks() {
    try {
      const snap = await getDocs(collection(db, "plannedWorks"));
      setPlannedWorks(snap.docs.map((d) => ({ id: d.id, ...d.data() })));
    } catch (err) {
      console.error("plannedWorks load error:", err);
      setPlannedWorks([]);
    }
  }

  async function updateField(collectionName, id, field, value) {
    const setterMap = {
      parts: setParts,
      calendar: setCalendarEvents,
      maintenanceReports: setReports,
      plannedWorks: setPlannedWorks,
    };

    const setter = setterMap[collectionName];

    if (setter) {
      setter((current) =>
        current.map((item) =>
          item.id === id ? { ...item, [field]: value } : item
        )
      );
    }

    await updateDoc(doc(db, collectionName, id), { [field]: value });
  }

  async function removeItem(collectionName, id) {
    await deleteDoc(doc(db, collectionName, id));
    if (collectionName === "parts") loadParts();
    if (collectionName === "calendar") loadCalendar();
    if (collectionName === "maintenanceReports") loadReports();
    if (collectionName === "plannedWorks") loadPlannedWorks();
  }

  async function addPart() {
    await addDoc(collection(db, "parts"), {
      equipment: "",
      lineName: "",
      partName: "",
      partNo: "",
      serialNo: "",
      maker: "",
      price: "",
      supplier: "",
      purchaseUrl: "",
      location: "",
      locationRack: "",
      lot: "",
      shelf: "",
      box: "",
      address: "",
      leadTime: "",
      reorderPoint: "",
      reorderQty: "",
      category: "手入力",
      maintenanceType: "交換",
      maintenanceDetail: "",
      equipment2Name: "",
      sectionName: "",
      method: "",
      standard: "",
      responseAction: "",
      result: "",
      prepDays: "",
      isMaintenanceTarget: false,
      cycle: 90,
      lastDate: "",
      owner: "",
      note: "",
      stockQty: 0,
      minStock: 1,
      stockNote: "",
      image: "",
      imageUrl: "",
    });
    loadParts();
  }

  async function addMaintenancePart() {
    await addDoc(collection(db, "parts"), {
      equipment: "",
      lineName: "",
      partName: "",
      partNo: "",
      serialNo: "",
      maker: "",
      price: "",
      supplier: "",
      purchaseUrl: "",
      location: "",
      locationRack: "",
      lot: "",
      shelf: "",
      box: "",
      address: "",
      leadTime: "",
      reorderPoint: "",
      reorderQty: "",
      category: "定期保全",
      maintenanceType: "交換",
      maintenanceDetail: "",
      equipment2Name: "",
      sectionName: "",
      method: "",
      standard: "",
      responseAction: "",
      result: "",
      prepDays: "",
      isMaintenanceTarget: true,
      cycle: 90,
      lastDate: "",
      owner: "",
      note: "",
      stockQty: 0,
      minStock: 1,
      stockNote: "",
      image: "",
      imageUrl: "",
    });
    await loadParts();
  }

  function startNewReport() {
    setNewReport(createBlankReport());
  }

  function cancelNewReport() {
    setNewReport(null);
  }

  async function saveNewReport() {
    if (!newReport) return;
    if (!newReport.equipment && !newReport.phenomenon) {
      alert("設備名または不具合現象を入力してください。");
      return;
    }

    const calc = calculateReport(newReport);
    const reportToSave = {
      ...newReport,
      ...calc,
      createdAt: newReport.createdAt || normalizeDateOnly(newReport.workStartDateTime) || todayText(),
      reportCreatedDate: newReport.reportCreatedDate || todayText(),
    };

    await addDoc(collection(db, "maintenanceReports"), reportToSave);

    await addDoc(collection(db, "calendar"), {
      date: reportToSave.createdAt || todayText(),
      time: "",
      title: `保全修理報告書：${reportToSave.equipment || "設備名なし"}`,
      detail: `${reportToSave.maintenanceType || ""} ${reportToSave.lineName || ""} ${reportToSave.phenomenon || ""} ${reportToSave.action || ""}`,
      owner: reportToSave.worker || reportToSave.createdBy || "",
      importance: reportToSave.approvalStatus === "承認済み" ? "通常" : "重要",
      category: "保全修理報告書",
      image: reportToSave.image || reportToSave.beforeImage || "",
    });

    setNewReport(null);
    await Promise.all([loadReports(), loadCalendar()]);
    alert("保存しました。カレンダーとAI検索に反映されます。");
  }

  function startNewCalendarEvent(date = selectedDate) {
    setEditingCalendarEventId(null);
    setNewCalendarEvent(createBlankCalendarEvent(date));
  }

  function startEditCalendarEvent(event) {
    if (!event?.sourceId && !event?.id) return;

    setEditingCalendarEventId(event.sourceId || event.id);
    setNewCalendarEvent({
      date: event.date || selectedDate || todayText(),
      time: event.time || "",
      title: event.title || "",
      detail: event.detail || "",
      owner: event.owner || "",
      importance: event.importance || "通常",
      category: event.category || "定期保全",
      image: event.image || "",
    });
  }

  function cancelNewCalendarEvent() {
    setNewCalendarEvent(null);
    setEditingCalendarEventId(null);
  }

  async function saveNewCalendarEvent() {
    if (!newCalendarEvent) return;
    if (!newCalendarEvent.title) {
      alert("予定タイトルを入力してください。");
      return;
    }

    const eventToSave = {
      date: newCalendarEvent.date || selectedDate || todayText(),
      time: newCalendarEvent.time || "",
      title: newCalendarEvent.title || "",
      detail: newCalendarEvent.detail || "",
      owner: newCalendarEvent.owner || "",
      importance: newCalendarEvent.importance || "通常",
      category: newCalendarEvent.category || "定期保全",
      image: newCalendarEvent.image || "",
    };

    if (editingCalendarEventId) {
      await updateDoc(doc(db, "calendar", editingCalendarEventId), eventToSave);
      alert("予定を更新しました。");
    } else {
      await addDoc(collection(db, "calendar"), eventToSave);
      alert("予定を保存しました。");
    }

    setNewCalendarEvent(null);
    setEditingCalendarEventId(null);
    await loadCalendar();
  }

  function startNewPlannedWork() {
    setNewPlannedWork(createBlankPlannedWork());
  }

  function cancelNewPlannedWork() {
    setNewPlannedWork(null);
  }

  async function saveNewPlannedWork() {
    if (!newPlannedWork) return;
    if (!newPlannedWork.title) {
      alert("工事件名を入力してください。");
      return;
    }

    const docRef = await addDoc(collection(db, "plannedWorks"), newPlannedWork);

    await addDoc(collection(db, "calendar"), {
      date: newPlannedWork.date || todayText(),
      time: "",
      title: `計画工事：${newPlannedWork.title}`,
      detail: `${newPlannedWork.equipment || ""} ${newPlannedWork.purpose || ""} ${newPlannedWork.detail || ""}`,
      owner: newPlannedWork.owner || "",
      importance: "重要",
      category: "計画工事",
      plannedWorkId: docRef.id,
      image: newPlannedWork.image || "",
    });

    setNewPlannedWork(null);
    await Promise.all([loadPlannedWorks(), loadCalendar()]);
    alert("計画工事を保存しました。カレンダーにも追加されました。");
  }

  function handleImageUpload(event, collectionName, rowId) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => updateField(collectionName, rowId, "image", reader.result);
    reader.readAsDataURL(file);
  }

  function handleDraftImageUpload(event, setter) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setter((current) => ({ ...current, image: reader.result }));
    };
    reader.readAsDataURL(file);
  }

  function handleReportDraftPhotoUpload(event, field) {
    const file = event.target.files[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onloadend = () => {
      setNewReport((current) => ({ ...current, [field]: reader.result }));
    };
    reader.readAsDataURL(file);
  }

  function toggleSection(key) {
    setOpenSections((current) => ({ ...current, [key]: !current[key] }));
  }

  function getCalendarDays() {
    const year = calendarMonth.getFullYear();
    const month = calendarMonth.getMonth();
    const firstDay = new Date(year, month, 1);
    const startDay = firstDay.getDay();
    const days = [];

    for (let i = 0; i < startDay; i++) days.push(null);

    const lastDate = new Date(year, month + 1, 0).getDate();

    for (let day = 1; day <= lastDate; day++) {
      const date = new Date(year, month, day);
      days.push(toLocalDateText(date));
    }

    return days;
  }

  function changeMonth(value) {
    const newDate = new Date(calendarMonth);
    newDate.setMonth(newDate.getMonth() + value);
    setCalendarMonth(newDate);
  }

  const maintenanceRows = useMemo(() => {
    return parts
      .filter((part) => part.isMaintenanceTarget === true)
      .map((part) => {
        const nextDate = part.nextDate || addDays(part.lastDate, part.cycle);
        const daysLeft = diffDays(nextDate);
        const status = getStatus(daysLeft);
        const maintenanceType = part.maintenanceType || part.category || "交換";
        const searchText = [
          maintenanceType,
          part.equipment,
          part.lineName,
          part.equipment2Name,
          part.sectionName,
          part.partName,
          part.partNo,
          part.serialNo,
          part.maker,
          part.maintenanceDetail,
          part.method,
          part.standard,
          part.responseAction,
          part.result,
          part.owner,
          part.note,
        ].join(" ");

        return { ...part, nextDate, daysLeft, status, maintenanceType, searchText };
      })
      .sort((a, b) => {
        if (a.daysLeft === "") return 1;
        if (b.daysLeft === "") return -1;
        return a.daysLeft - b.daysLeft;
      });
  }, [parts]);

  const filteredMaintenanceRows = useMemo(() => {
    const keyword = maintenanceSearch.toLowerCase().trim();
    const keywords = keyword ? keyword.split(/\s+/) : [];

    const filtered = maintenanceRows.filter((row) => {
      const typeOk = maintenanceTypeFilter === "全て" || row.maintenanceType === maintenanceTypeFilter;
      const keywordOk = keywords.length === 0 || containsAll(row.searchText, keywords);
      return typeOk && keywordOk;
    });

    const getText = (row) => [
      row.equipment,
      row.lineName,
      row.sectionName,
      row.equipment1Name,
      row.equipment2Name,
      row.partName,
      row.maintenanceDetail,
    ].filter(Boolean).join(" ");

    return [...filtered].sort((a, b) => {
      if (maintenanceSort === "az") {
        return getText(a).localeCompare(getText(b), "ja");
      }
      if (maintenanceSort === "type") {
        return String(a.maintenanceType || "").localeCompare(String(b.maintenanceType || ""), "ja");
      }
      if (maintenanceSort === "equipment") {
        return String(a.equipment || a.lineName || "").localeCompare(String(b.equipment || b.lineName || ""), "ja");
      }
      if (maintenanceSort === "owner") {
        return String(a.owner || "").localeCompare(String(b.owner || ""), "ja");
      }

      if (a.daysLeft === "") return 1;
      if (b.daysLeft === "") return -1;
      return Number(a.daysLeft) - Number(b.daysLeft);
    });
  }, [maintenanceRows, maintenanceSearch, maintenanceTypeFilter, maintenanceSort]);

  const spareRows = useMemo(() => {
    return parts.map((part) => {
      const stockQty = Number(part.stockQty || 0);
      const minStock = Number(part.minStock || 1);
      let stockStatus = "🟢 在庫OK";

      if (stockQty <= 0) {
        stockStatus = "🔴 在庫なし";
      } else if (stockQty <= minStock) {
        stockStatus = "🟡 在庫注意";
      }

      const searchText = [
        part.equipment,
        part.lineName,
        part.partName,
        part.partNo,
        part.serialNo,
        part.maker,
        part.supplier,
        part.purchaseUrl,
        part.location,
        part.locationRack,
        part.lot,
        part.shelf,
        part.box,
        part.address,
        part.category,
        part.note,
        part.stockNote,
      ].join(" ");

      return { ...part, stockQty, minStock, stockStatus, searchText };
    });
  }, [parts]);

  const filteredSpareRows = useMemo(() => {
    const keyword = spareSearch.toLowerCase().trim();
    if (!keyword) return spareRows;
    const keywords = keyword.split(/\s+/);
    return spareRows.filter((row) => containsAll(row.searchText, keywords));
  }, [spareRows, spareSearch]);

  const overCount = maintenanceRows.filter((r) => r.status === "交換超過").length;
  const nearCount = maintenanceRows.filter((r) => r.status === "交換間近").length;
  const lowStockCount = spareRows.filter((r) => r.stockStatus.includes("なし") || r.stockStatus.includes("不足")).length;
  const monthReportCount = reports.filter((report) =>
    (report.createdAt || "").startsWith(new Date().toISOString().slice(0, 7))
  ).length;


  const unifiedCalendarEvents = useMemo(() => {
    const reportEvents = reports
      .filter((report) => report.createdAt || report.troubleDateTime || report.workStartDateTime)
      .map((report) => {
        const date = String(report.createdAt || report.troubleDateTime || report.workStartDateTime || "").slice(0, 10);
        return {
          id: `report-${report.id}`,
          sourceId: report.id,
          sourceType: "maintenanceReports",
          page: "report",
          date,
          time: "",
          title: `保全報告：${report.equipment || report.lineName || "設備名なし"}`,
          detail: [
            report.phenomenon,
            report.troublePoint,
            report.action,
          ].filter(Boolean).join(" / "),
          owner: report.worker || "",
          importance: "重要",
          category: "保全報告書",
          image: report.image || "",
          deletable: false,
        };
      })
      .filter((event) => event.date);

    const maintenanceEvents = maintenanceRows
      .filter((part) => part.nextDate)
      .map((part) => ({
        id: `maintenance-${part.id}`,
        sourceId: part.id,
        sourceType: "parts",
        page: "maintenance",
        date: part.nextDate,
        time: "",
        title: `${part.maintenanceType || "定期保全"}：${part.equipment || part.lineName || part.partName || "設備名なし"}`,
        detail: [
          part.equipment2Name ? `装置：${part.equipment2Name}` : "",
          part.sectionName ? `部位：${part.sectionName}` : "",
          part.maintenanceDetail ? `内容：${part.maintenanceDetail}` : "",
          part.partName ? `部品：${part.partName}` : "",
          part.partNo ? `型式：${part.partNo}` : "",
          part.method ? `方法：${part.method}` : "",
          part.standard ? `基準：${part.standard}` : "",
          part.status ? `状態：${part.status}` : "",
          part.daysLeft !== "" ? `残日数：${part.daysLeft}` : "",
        ].filter(Boolean).join(" / "),
        owner: part.owner || "",
        importance: part.status === "交換超過" || part.status === "交換間近" ? "重要" : "通常",
        category: "定期保全",
        image: part.image || "",
        deletable: false,
      }));

    const manualEvents = calendarEvents.map((event) => ({
      ...event,
      sourceId: event.id,
      sourceType: "calendar",
      page: "calendar",
      deletable: true,
    }));

    // 計画工事を保存すると calendar にも1件作成されます。
    // そのため plannedWorks をそのまま足すと同じ予定が2枚表示されます。
    // calendar 側に plannedWorkId があるものは重複防止のため plannedWorks 側を表示しません。
    const linkedPlannedWorkIds = new Set(
      manualEvents
        .map((event) => event.plannedWorkId)
        .filter(Boolean)
    );

    const plannedWorkEvents = plannedWorks
      .filter((work) => work.date)
      .filter((work) => !linkedPlannedWorkIds.has(work.id))
      .map((work) => ({
        id: `planned-${work.id}`,
        sourceId: work.id,
        sourceType: "plannedWorks",
        page: "work",
        date: work.date,
        time: "",
        title: `計画工事：${work.title || work.equipment || "工事"}`,
        detail: [work.equipment, work.purpose, work.detail, work.status].filter(Boolean).join(" / "),
        owner: work.owner || "",
        importance: "重要",
        category: "計画工事",
        image: work.image || "",
        deletable: false,
      }));

    return [
      ...manualEvents,
      ...reportEvents,
      ...maintenanceEvents,
      ...plannedWorkEvents,
    ].sort((a, b) => `${a.date || ""}${a.time || ""}`.localeCompare(`${b.date || ""}${b.time || ""}`));
  }, [calendarEvents, reports, maintenanceRows, plannedWorks]);

  const filteredReports = useMemo(() => {
    const keyword = reportSearch.toLowerCase().trim();
    const sorted = [...reports].sort((a, b) => (b.createdAt || "").localeCompare(a.createdAt || ""));
    if (!keyword) return sorted;

    const keywords = keyword.split(/\s+/);

    return sorted.filter((r) =>
      containsAll(
        [
          r.createdAt,
          r.maintenanceType,
          r.groupName,
          r.lineName,
          r.equipment,
          r.phenomenon,
          r.troublePoint,
          r.why1,
          r.why2,
          r.why3,
          r.action,
          r.worker,
          r.approvalStatus,
          r.dbInputBy,
          r.approvedBy,
          r.inspectedBy,
          r.createdBy,
          r.note,
        ].join(" "),
        keywords
      )
    );
  }, [reports, reportSearch]);

  const globalResults = useMemo(() => {
    const keyword = globalSearch.toLowerCase().trim();
    if (!keyword) return [];

    const keywords = keyword.split(/\s+/);

    const allItems = [
      ...reports.map((r) => ({
        category: "📝 保全報告書",
        page: "report",
        title: r.equipment || "設備名なし",
        date: r.createdAt || "-",
        text: `${r.lineName || ""} ${r.phenomenon || ""} ${r.troublePoint || ""} ${r.why1 || ""} ${r.why2 || ""} ${r.why3 || ""} ${r.action || ""} ${r.note || ""}`,
      })),

      ...maintenanceRows.map((p) => ({
        category: "🔧 定期保全",
        page: "maintenance",
        title: p.equipment || "設備名なし",
        date: p.nextDate || "-",
        text: `${p.partName || ""} ${p.partNo || ""} ${p.supplier || ""} ${p.location || ""} ${p.status || ""} ${p.note || ""}`,
      })),

      ...spareRows.map((p) => ({
        category: "📦 予備品管理",
        page: "spare",
        title: p.partName || "部品名なし",
        date: p.leadTime || "-",
        text: `${p.equipment || ""} ${p.lineName || ""} ${p.partNo || ""} ${p.serialNo || ""} ${p.maker || ""} ${p.supplier || ""} ${p.purchaseUrl || ""} ${p.location || ""} ${p.locationRack || ""} ${p.category || ""} ${p.stockStatus || ""} ${p.stockNote || ""}`,
      })),

      ...calendarEvents.map((c) => ({
        category: "📅 カレンダー",
        page: "calendar",
        title: c.title || "予定",
        date: c.date || "-",
        text: `${c.category || ""} ${c.detail || ""} ${c.owner || ""} ${c.importance || ""}`,
      })),

      ...plannedWorks.map((w) => ({
        category: "🏗️ 計画工事",
        page: "work",
        title: w.title || "計画工事",
        date: w.date || "-",
        text: `${w.equipment || ""} ${w.purpose || ""} ${w.detail || ""} ${w.owner || ""} ${w.status || ""} ${w.note || ""}`,
      })),
    ];

    return allItems
      .map((item) => {
        const allText = `${item.category} ${item.title} ${item.date} ${item.text}`.toLowerCase();
        const score = keywords.filter((k) => allText.includes(k)).length;
        return { ...item, score };
      })
      .filter((item) => item.score > 0)
      .sort((a, b) => b.score - a.score);
  }, [globalSearch, reports, maintenanceRows, spareRows, calendarEvents, plannedWorks]);

  const aiResults = useMemo(() => {
    const keyword = aiSearch.toLowerCase().trim();
    if (!keyword) return [];

    const keywords = keyword.split(/\s+/);

    const allItems = [
      ...reports.map((r) => ({
        category: "📝 保全報告書",
        page: "report",
        title: r.equipment || "設備名なし",
        date: r.createdAt || "-",
        text: `${r.lineName || ""} ${r.phenomenon || ""} ${r.troublePoint || ""} ${r.why1 || ""} ${r.why2 || ""} ${r.why3 || ""} ${r.action || ""} ${r.note || ""}`,
      })),
      ...maintenanceRows.map((p) => ({
        category: "🔧 定期保全",
        page: "maintenance",
        title: p.equipment || "設備名なし",
        date: p.nextDate || "-",
        text: `${p.partName || ""} ${p.partNo || ""} ${p.status || ""} ${p.note || ""}`,
      })),
      ...spareRows.map((p) => ({
        category: "📦 予備品管理",
        page: "spare",
        title: p.partName || "部品名なし",
        date: p.leadTime || "-",
        text: `${p.equipment || ""} ${p.lineName || ""} ${p.partNo || ""} ${p.serialNo || ""} ${p.maker || ""} ${p.supplier || ""} ${p.purchaseUrl || ""} ${p.location || ""} ${p.locationRack || ""} ${p.category || ""} ${p.stockStatus || ""}`,
      })),
      ...calendarEvents.map((c) => ({
        category: "📅 カレンダー",
        page: "calendar",
        title: c.title || "予定",
        date: c.date || "-",
        text: `${c.category || ""} ${c.detail || ""} ${c.owner || ""}`,
      })),
      ...plannedWorks.map((w) => ({
        category: "🏗️ 計画工事",
        page: "work",
        title: w.title || "計画工事",
        date: w.date || "-",
        text: `${w.equipment || ""} ${w.purpose || ""} ${w.detail || ""} ${w.status || ""} ${w.note || ""}`,
      })),
    ];

    return allItems
      .map((item) => {
        const allText = `${item.category} ${item.title} ${item.date} ${item.text}`.toLowerCase();
        const score = keywords.filter((k) => allText.includes(k)).length;
        return { ...item, score };
      })
      .filter((item) => item.score > 0)
      .sort((a, b) => b.score - a.score);
  }, [aiSearch, reports, maintenanceRows, spareRows, calendarEvents, plannedWorks]);

  function makeAiAnswer() {
    if (!aiSearch.trim()) {
      setAiLevel("");
      setAiAnswer("検索したい内容を入力してください。");
      return;
    }

    if (aiResults.length === 0) {
      setAiLevel("🟢 履歴なし");
      setAiAnswer(
        "関連する履歴は見つかりませんでした。\n\n新しいトラブルまたは新しい部品の可能性があります。保全報告書、定期保全、予備品管理に情報を登録してください。"
      );
      return;
    }

    const best = aiResults[0];
    const text = `${aiSearch} ${best.title} ${best.text}`;
    const highWords = ["停止", "ライン停止", "サーボ", "モーター", "安全", "異常停止", "漏れ", "火花", "焼損", "破損", "緊急"];
    const middleWords = ["異常", "交換", "確認", "不具合", "センサー", "ロードセル", "エラー", "調整", "在庫不足"];
    const highHit = highWords.some((word) => text.includes(word));
    const middleHit = middleWords.some((word) => text.includes(word));

    let level = "🟢 軽微";
    let reason = "重大な停止や安全に関わるキーワードは少ないです。";

    if (highHit || aiResults.length >= 4) {
      level = "🔴 緊急確認";
      reason = "停止、安全、重要設備、または複数の関連履歴が見つかりました。";
    } else if (middleHit || aiResults.length >= 1) {
      level = "🟡 注意";
      reason = "異常、交換、確認、センサー系、在庫不足など注意が必要な内容が含まれています。";
    }

    setAiLevel(level);
    setAiAnswer(
      `【Maintenance AI 分析結果】\n\n危険度：${level}\n\n理由：\n・${reason}\n\n関連データ：${aiResults.length}件\n\n一番近い履歴：\n種類：${best.category}\n日付：${best.date}\nタイトル：${best.title}\n\n内容：\n${best.text}\n\n確認ポイント：\n・同じ設備、同じ部品、同じ異常内容がないか確認してください。\n・過去の原因と処置内容を参考にしてください。\n・再発している場合は、再発防止内容の見直しが必要です。\n・在庫不足が関係する場合は、予備品管理を確認してください。`
    );
  }

  async function createAutoReport() {
    const input = autoReportInput.trim();
    if (!input) {
      alert("内容を入力してください。例：78-60 ロードセル異常 荷重確認");
      return;
    }

    const words = input.split(/\s+/);
    const equipment = words[0] || "";

    let phenomenon = `${input} の不具合が発生。`;
    let why1 = "設備または部品に異常が発生したため。";
    let why2 = "原因箇所の確認が必要なため。";
    let why3 = "再発防止のため、発生条件と処置内容の記録が必要なため。";
    let action = "現象確認、原因調査、関係部品の確認を実施。必要に応じて調整・交換・清掃を行う。";
    let recurrencePrevention = "同様の異常が再発しないよう、点検項目追加と発生条件の記録を行う。";
    let note = "Maintenance AI 自動作成のため、内容を確認して必要に応じて修正してください。";

    if (input.includes("ロードセル")) {
      phenomenon = "ロードセルの異常が発生し、荷重値の確認が必要な状態。";
      why1 = "ロードセル信号または荷重値に異常が発生したため。";
      why2 = "配線、コネクタ、取付状態、またはロードセル本体の不具合が考えられるため。";
      why3 = "経年劣化、過負荷、振動、接触不良により検出値が不安定になった可能性があるため。";
      action = "ロードセルの表示値確認、配線・コネクタ確認、取付状態確認を実施。必要に応じてロードセル交換または再調整を行う。";
      recurrencePrevention = "定期保全時にロードセル値の確認、配線固定状態の確認、異常傾向の記録を行う。";
    } else if (input.includes("センサー")) {
      phenomenon = "センサー異常により設備動作が不安定、または検出不良が発生。";
      why1 = "センサー信号が正常に入っていないため。";
      why2 = "センサー位置ズレ、汚れ、断線、コネクタ接触不良が考えられるため。";
      why3 = "振動や経年劣化により検出状態が悪化した可能性があるため。";
      action = "センサー清掃、位置調整、配線確認、I/O確認を実施。必要に応じてセンサー交換を行う。";
      recurrencePrevention = "定期保全にセンサー清掃・位置確認を追加し、固定状態を定期確認する。";
    }

    if (aiResults[0]) {
      note += `\n\n関連履歴あり：${aiResults[0].category} / ${aiResults[0].date} / ${aiResults[0].title}`;
    }

    await addDoc(collection(db, "maintenanceReports"), {
      ...createBlankReport(),
      maintenanceType: "突発保全",
      functionDownRate: "100",
      equipment,
      phenomenon,
      why1,
      why2,
      why3,
      action,
      recurrencePrevention,
      outflowPrevention: "同様の異常が他設備で発生していないか確認する。",
      note,
    });

    setAutoReportInput("");
    await loadReports();
    setPage("report");
  }

  function renderGlobalSearchBox() {
    return (
      <div className="tableWrap" style={{ marginBottom: "18px" }}>
        <h2>🔍 AI統合検索</h2>
        <p>保全報告書・定期保全・予備品管理・カレンダー・計画工事をまとめて検索できます。</p>

        <div style={{ display: "flex", gap: "10px", alignItems: "center" }}>
          <input
            value={globalSearch}
            onChange={(e) => setGlobalSearch(e.target.value)}
            placeholder="例：ロードセル、78-60、センサー、異常停止、在庫不足"
          />
          <button
            className="primaryButton"
            onClick={() => {
              setAiSearch(globalSearch);
              setPage("ai");
            }}
          >
            <Search size={16} /> AI分析
          </button>
        </div>

        {globalSearch && (
          <div style={{ marginTop: "16px" }}>
            <h3>検索結果：{globalResults.length}件</h3>
            {globalResults.length === 0 && <p>関連データが見つかりません。</p>}
            {globalResults.slice(0, 8).map((item, index) => (
              <div
                key={index}
                className="calendarEditCard"
                style={{ cursor: "pointer" }}
                onClick={() => setPage(item.page)}
              >
                <b>{item.category} / {item.date}</b>
                <h3>{item.title}</h3>
                <p>{item.text || "-"}</p>
              </div>
            ))}
          </div>
        )}
      </div>
    );
  }

  function Section({ sectionKey, title, children }) {
    const open = openSections[sectionKey];
    return (
      <div className="calendarEditCard" style={{ marginTop: "14px" }}>
        <div
          onClick={() => toggleSection(sectionKey)}
          style={{
            display: "flex",
            justifyContent: "space-between",
            alignItems: "center",
            cursor: "pointer",
          }}
        >
          <h3>{title}</h3>
          <strong>{open ? "▲" : "▼"}</strong>
        </div>
        {open && <div style={{ marginTop: "10px" }}>{children}</div>}
      </div>
    );
  }

const formatExcelDate = (value) => {
  if (!value) return "";

  if (typeof value === "number") {
    const date = XLSX.SSF.parse_date_code(value);
    if (!date) return "";
    const yyyy = date.y;
    const mm = String(date.m).padStart(2, "0");
    const dd = String(date.d).padStart(2, "0");
    return `${yyyy}-${mm}-${dd}`;
  }

  try {
    const date = new Date(value);
    if (!isNaN(date.getTime())) {
      return toLocalDateText(date);
    }
  } catch {}

  return String(value).replace(/\//g, "-").split(" ")[0];
};

const buildReportFromExcelRow = (row, fileName = "") => {
  const report = {
    ...createBlankReport(),

    reportType: row?.[0] || "保全作業報告書",
    worker: row?.[1] || "",
    createdBy: row?.[1] || "",
    maintenanceType: row?.[2] || "CM",

    troubleDateTime: normalizeDateTime(row?.[3]),
    workStartDateTime: normalizeDateTime(row?.[4]),
    workEndDateTime: normalizeDateTime(row?.[5]),
    productionStartDateTime: normalizeDateTime(row?.[6]),
    stopExclusionHours: toNumber(row?.[7], 0),
    functionDownRate: toNumber(row?.[8], 100) <= 1 ? toNumber(row?.[8], 1) * 100 : toNumber(row?.[8], 100),

    createdAt: normalizeDateOnly(row?.[4]) || todayText(),

    groupName: row?.[10] || "",
    lineName: row?.[11] || "",
    equipment: row?.[12] || "",

    phenomenon: row?.[13] || "",
    troublePoint: row?.[14] || "",

    why1: row?.[15] || "",
    why2: row?.[16] || "",
    why3: row?.[17] || "",

    action: row?.[18] || "",

    recurrenceCategory: row?.[19] || "",
    recurrencePrevention: row?.[20] || "",
    outflowPrevention: row?.[21] || "",
    changeRank: row?.[22] || "",
    fpInspection: row?.[23] || "",

    laborHours: toNumber(row?.[24], 0),
    laborCost: toNumber(row?.[25], 0),
    partsCost: toNumber(row?.[26], 0),
    totalCost: toNumber(row?.[27], 0),

    approvalStatus: "Excel取込",
    note: fileName ? `Excel取込ファイル：${fileName}` : "",
  };

  return { ...report, ...calculateReport(report) };
};

const getReportRowFromWorkbook = (workbook) => {
  const sheet =
    workbook.Sheets["DBコピペ用"] ||
    workbook.Sheets[workbook.SheetNames[0]];

  const rows = XLSX.utils.sheet_to_json(sheet, {
    header: 1,
    raw: false,
  });

  return rows[1];
};

const handleReportExcelUpload = async (e) => {
  const file = e.target.files[0];
  if (!file) return;

  const reader = new FileReader();

  reader.onload = (evt) => {
    try {
      const data = evt.target.result;
      const workbook = XLSX.read(data, { type: "binary" });
      const row = getReportRowFromWorkbook(workbook);

      if (!row) {
        alert("Excelデータが見つかりませんでした。");
        return;
      }

      const report = buildReportFromExcelRow(row, file.name);
      setNewReport((prev) => ({ ...prev, ...report }));

      alert("Excelデータをフォームへ取込みました。");
    } catch (error) {
      console.error("Excel import error:", error);
      alert("Excel取込エラーが発生しました。");
    }
  };

  reader.onerror = () => {
    alert("ファイル読込エラーが発生しました。");
  };

  reader.readAsBinaryString(file);
};

const handleBulkReportExcelUpload = async (e) => {
  const files = Array.from(e.target.files || []);
  if (files.length === 0) return;

  let success = 0;
  let failed = 0;

  for (const file of files) {
    try {
      const data = await file.arrayBuffer();
      const workbook = XLSX.read(data);
      const row = getReportRowFromWorkbook(workbook);

      if (!row) {
        failed += 1;
        continue;
      }

      const report = buildReportFromExcelRow(row, file.name);
      report.note = `Excel一括取込ファイル：${file.name}`;

      await addDoc(collection(db, "maintenanceReports"), report);
      success += 1;
    } catch (error) {
      console.error("Import error:", file.name, error);
      failed += 1;
    }
  }

  await loadReports();

  alert(`一括取込完了
成功：${success}件
失敗：${failed}件`);
};

  function ReportDraftForm() {
    if (!newReport) return null;

    const calc = calculateReport(newReport);
    const setReport = (field, value) => setNewReport((current) => ({ ...current, [field]: value }));

    return (
      <div className="tableWrap" style={{ border: "2px solid #2563eb" }}>
        <div
          style={{
            border: "2px solid #0f172a",
            borderRadius: "16px",
            overflow: "hidden",
            background: "#fff",
          }}
        >
          <div
            style={{
              display: "grid",
              gridTemplateColumns: "1fr 420px",
              borderBottom: "2px solid #0f172a",
            }}
          >
            <div style={{ padding: "18px", textAlign: "center" }}>
              <h1 style={{ margin: 0, fontSize: "30px" }}>保全作業報告書</h1>
              <p style={{ margin: "8px 0 0", color: "#64748b" }}>
                Excel原紙の項目を残し、入力しやすいようにブロック別で管理します。
              </p>
            </div>

            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", borderLeft: "2px solid #0f172a" }}>
              {[
                ["DB入力", "dbInputBy", "dbInputDate"],
                ["承認", "approvedBy", "approvedDate"],
                ["点検", "inspectedBy", "inspectedDate"],
                ["作成", "createdBy", "reportCreatedDate"],
              ].map(([label, nameKey, dateKey]) => (
                <div key={label} style={{ borderRight: "1px solid #94a3b8", padding: "8px", minHeight: "96px" }}>
                  <strong>{label}</strong>
                  <input
                    placeholder="氏名"
                    value={newReport[nameKey] || ""}
                    onChange={(e) => setReport(nameKey, e.target.value)}
                    style={{ marginTop: "6px" }}
                  />
                  <input
                    type="date"
                    value={newReport[dateKey] || ""}
                    onChange={(e) => setReport(dateKey, e.target.value)}
                    style={{ marginTop: "6px" }}
                  />
                </div>
              ))}
            </div>
          </div>

          <div style={{ padding: "14px", background: reportStatusColor(newReport.approvalStatus), display: "flex", gap: "12px", flexWrap: "wrap", alignItems: "center" }}>
            <strong>承認ステータス</strong>
            <select value={newReport.approvalStatus || "下書き"} onChange={(e) => setReport("approvalStatus", e.target.value)} style={{ maxWidth: "180px" }}>
              <option value="下書き">下書き</option>
              <option value="点検待ち">点検待ち</option>
              <option value="承認待ち">承認待ち</option>
              <option value="承認済み">承認済み</option>
              <option value="差戻し">差戻し</option>
              <option value="Excel取込">Excel取込</option>
            </select>

            <button className="primaryButton" onClick={saveNewReport}>
              <Save size={16} /> 保存
            </button>
            <button className="deleteButton" onClick={cancelNewReport}>
              <X size={16} /> キャンセル
            </button>
          </div>
        </div>

        <div style={{ marginTop: "12px" }}>
          <p style={{ margin: "4px 0", fontWeight: "bold" }}>1件Excel取込</p>
          <input type="file" accept=".xlsx,.xls,.xlsm" onChange={handleReportExcelUpload} />

          <p style={{ margin: "12px 0 4px", fontWeight: "bold" }}>複数Excel一括取込</p>
          <input type="file" accept=".xlsx,.xls,.xlsm" multiple onChange={handleBulkReportExcelUpload} />
        </div>

        <Section sectionKey="basic" title="📌 基本情報・設備情報">
          <div className="reportGrid">
            <label>作成日<input type="date" value={newReport.createdAt || ""} onChange={(e) => setReport("createdAt", e.target.value)} /></label>
            <label>保全分類
              <select value={newReport.maintenanceType || "CM"} onChange={(e) => setReport("maintenanceType", e.target.value)}>
                <option value="CM">CM</option>
                <option value="BM">BM</option>
                <option value="PM">PM</option>
                <option value="その他">その他</option>
              </select>
            </label>
            <label>グループ名<input value={newReport.groupName || ""} onChange={(e) => setReport("groupName", e.target.value)} /></label>
            <label>ライン名<input value={newReport.lineName || ""} onChange={(e) => setReport("lineName", e.target.value)} /></label>
            <label>設備名<input value={newReport.equipment || ""} onChange={(e) => setReport("equipment", e.target.value)} /></label>
            <label>作業者<input value={newReport.worker || ""} onChange={(e) => { setReport("worker", e.target.value); setReport("createdBy", newReport.createdBy || e.target.value); }} /></label>
          </div>
        </Section>

        <Section sectionKey="time" title="⏱️ 時間・停止時間（自動計算）">
          <div className="reportGrid">
            <label>①不具合発生日時<input type="datetime-local" value={newReport.troubleDateTime || ""} onChange={(e) => setReport("troubleDateTime", e.target.value)} /></label>
            <label>②保全作業開始日時<input type="datetime-local" value={newReport.workStartDateTime || ""} onChange={(e) => setReport("workStartDateTime", e.target.value)} /></label>
            <label>③保全作業完了日時<input type="datetime-local" value={newReport.workEndDateTime || ""} onChange={(e) => setReport("workEndDateTime", e.target.value)} /></label>
            <label>④生産開始日時<input type="datetime-local" value={newReport.productionStartDateTime || ""} onChange={(e) => setReport("productionStartDateTime", e.target.value)} /></label>
            <label>⑤停止除外時間H<input type="number" step="0.1" value={newReport.stopExclusionHours ?? 0} onChange={(e) => setReport("stopExclusionHours", e.target.value)} /></label>
            <label>⑥機能低下(%)<input type="number" step="1" value={newReport.functionDownRate ?? 100} onChange={(e) => setReport("functionDownRate", e.target.value)} /></label>
            <label>⑦停止時間H<input readOnly value={calc.stopTimeHours} /></label>
          </div>
          <p style={{ color: "#64748b" }}>※⑦停止時間＝（④生産開始日時 - ①不具合発生日時 - ⑤停止除外時間）×⑥機能低下率</p>
        </Section>

        <Section sectionKey="trouble" title="📝 不具合内容・処置">
          <h3>不具合現象</h3>
          <textarea value={newReport.phenomenon || ""} onChange={(e) => setReport("phenomenon", e.target.value)} />
          <h3>不具合箇所</h3>
          <textarea value={newReport.troublePoint || ""} onChange={(e) => setReport("troublePoint", e.target.value)} />
          <h3>処置内容</h3>
          <textarea value={newReport.action || ""} onChange={(e) => setReport("action", e.target.value)} />
          <h3>リンク先</h3>
          <input value={newReport.linkUrl || ""} onChange={(e) => setReport("linkUrl", e.target.value)} placeholder="写真・図面・詳細資料リンク" />
        </Section>

        <Section sectionKey="why" title="🔍 不具合原因・なぜなぜ分析">
          {[1, 2, 3, 4, 5].map((num) => (
            <label key={num}>なぜ{num}<textarea value={newReport[`why${num}`] || ""} onChange={(e) => setReport(`why${num}`, e.target.value)} /></label>
          ))}
        </Section>

        <Section sectionKey="prevention" title="🛠️ 再発防止・流出防止・変化点">
          <div className="reportGrid">
            <label>再発防止区分
              <select value={newReport.recurrenceCategory || "必要"} onChange={(e) => setReport("recurrenceCategory", e.target.value)}>
                <option value="必要">必要</option>
                <option value="不要">不要</option>
                <option value="必要 実施完了">必要 実施完了</option>
                <option value="必要 未実施">必要 未実施</option>
              </select>
            </label>
            <label>変化点ランク<input value={newReport.changeRank || ""} onChange={(e) => setReport("changeRank", e.target.value)} /></label>
            <label>FP点検<input value={newReport.fpInspection || ""} onChange={(e) => setReport("fpInspection", e.target.value)} /></label>
          </div>
          <h3>再発防止・残工事</h3>
          <textarea value={newReport.recurrencePrevention || ""} onChange={(e) => setReport("recurrencePrevention", e.target.value)} />
          <h3>流出防止</h3>
          <textarea value={newReport.outflowPrevention || ""} onChange={(e) => setReport("outflowPrevention", e.target.value)} />
        </Section>

        <Section sectionKey="cost" title="💰 保全費用（自動計算）">
          <div className="reportGrid">
            <label>作業者数<input type="number" value={newReport.workerCount || 1} onChange={(e) => setReport("workerCount", e.target.value)} /></label>
            <label>時間単価<input type="number" value={newReport.laborRate || 3000} onChange={(e) => setReport("laborRate", e.target.value)} /></label>
            <label>保全工数H<input readOnly value={calc.laborHours} /></label>
            <label>労務費<input readOnly value={calc.laborCost.toLocaleString()} /></label>
          </div>

          <h3>保全交換部品費・外注費</h3>
          {[1, 2, 3].map((num) => (
            <div className="reportGrid" key={num} style={{ marginBottom: "8px" }}>
              <label>部品名{num}<input value={newReport[`partName${num}`] || ""} onChange={(e) => setReport(`partName${num}`, e.target.value)} /></label>
              <label>a 個数<input type="number" value={newReport[`partQty${num}`] || ""} onChange={(e) => setReport(`partQty${num}`, e.target.value)} /></label>
              <label>b 単価<input type="number" value={newReport[`partUnitPrice${num}`] || ""} onChange={(e) => setReport(`partUnitPrice${num}`, e.target.value)} /></label>
              <label>部品費(a×b)<input readOnly value={(calc[`partAmount${num}`] || 0).toLocaleString()} /></label>
            </div>
          ))}

          <div className="cards" style={{ marginTop: "12px" }}>
            <div className="card"><span>⑨部品費合計</span><strong>¥{calc.partsCost.toLocaleString()}</strong></div>
            <div className="card"><span>⑦労務費</span><strong>¥{calc.laborCost.toLocaleString()}</strong></div>
            <div className="card red"><span>⑩保全費用合計</span><strong>¥{calc.totalCost.toLocaleString()}</strong></div>
          </div>

          <h3>在庫・備考</h3>
          <div className="reportGrid">
            <label>保全交換部品<input value={newReport.replacedPart || ""} onChange={(e) => setReport("replacedPart", e.target.value)} /></label>
            <label>在庫数<input value={newReport.stockQty || ""} onChange={(e) => setReport("stockQty", e.target.value)} /></label>
          </div>
        </Section>

        <Section sectionKey="other" title="📷 写真・備考">
          <div className="reportGrid">
            <label>工事前写真<input type="file" accept="image/*" onChange={(e) => handleReportDraftPhotoUpload(e, "beforeImage")} /></label>
            <label>工事後写真<input type="file" accept="image/*" onChange={(e) => handleReportDraftPhotoUpload(e, "afterImage")} /></label>
          </div>
          <div style={{ display: "flex", gap: "14px", flexWrap: "wrap" }}>
            {newReport.beforeImage && <img src={newReport.beforeImage} alt="工事前" className="calendarPhoto" />}
            {newReport.afterImage && <img src={newReport.afterImage} alt="工事後" className="calendarPhoto" />}
          </div>
          <h3>備考</h3>
          <textarea value={newReport.note || ""} onChange={(e) => setReport("note", e.target.value)} />
        </Section>

        <div style={{ display: "flex", gap: "10px", marginTop: "18px" }}>
          <button className="primaryButton" onClick={saveNewReport}><Save size={16} /> 保存</button>
          <button className="deleteButton" onClick={cancelNewReport}><X size={16} /> キャンセル</button>
        </div>
      </div>
    );
  }


function renderHome() {
  return (
    <>
      <div
        className="tableWrap"
        style={{
          textAlign: "center",
          padding: "20px",
          maxWidth: "900px",
          margin: "0 auto"
        }}
      >
        <div className="javaLogo">

          <div>
            <h1
              style={{
                fontSize: "56px",
                fontWeight: "900",
                color: "#0057ff",
                margin: "0",
                letterSpacing: "3px",
                textShadow: "0 4px 12px rgba(0,87,255,0.25)"
              }}
            >
              MIYAMA
            </h1>

          
            <p
              style={{
                fontSize: "22px",
                color: "#64748b",
                margin: "0"
              }}
            >
              One Team Maintenance Group
            </p>
          </div>
        </div>

        <p
          style={{
            marginTop: "20px",
            color: "#64748b",
            fontSize: "18px"
          }}
        >
          設備保全を、もっとスマートに。
        </p>

        <div style={{ maxWidth: "760px", margin: "24px auto 0" }}>
          <input
            value={globalSearch}
            onChange={(e) => setGlobalSearch(e.target.value)}
            placeholder="設備・部品・トラブル内容を検索してください"
            style={{
              textAlign: "center",
              fontSize: "18px",
              minHeight: "52px"
            }}
          />
        </div>

        <div
          style={{
            display: "flex",
            justifyContent: "center",
            gap: "12px",
            marginTop: "20px",
            flexWrap: "wrap"
          }}
        >
          <button
            className="primaryButton"
            onClick={() => {
              setAiSearch(globalSearch);
              setPage("ai");
            }}
          >
            <Search size={16} /> AI検索へ
          </button>

          <button
            className="primaryButton"
            onClick={() => setPage("report")}
          >
            システムへ入る
          </button>
        </div>
      </div>

      {globalSearch && renderGlobalSearchBox()}

      <div className="cards">
        <div className="card red">
          <span>交換超過</span>
          <strong>{overCount}</strong>
        </div>

        <div className="card yellow">
          <span>交換間近</span>
          <strong>{nearCount}</strong>
        </div>

        <div className="card red">
          <span>在庫不足</span>
          <strong>{lowStockCount}</strong>
        </div>

        <div className="card">
          <span>今月報告書</span>
          <strong>{monthReportCount}</strong>
        </div>
      </div>

      <div className="cards" style={{ marginTop: "20px" }}>
        <div className="card" onClick={() => setPage("ai")} style={{ cursor: "pointer" }}>
          <span>🔍 AI検索</span>
          <strong>検索</strong>
        </div>

        <div className="card" onClick={() => setPage("report")} style={{ cursor: "pointer" }}>
          <span>📝 保全報告書</span>
          <strong>{reports.length}</strong>
        </div>

        <div className="card" onClick={() => setPage("maintenance")} style={{ cursor: "pointer" }}>
          <span>🔧 定期保全</span>
          <strong>{maintenanceRows.length}</strong>
        </div>

        <div className="card" onClick={() => setPage("spare")} style={{ cursor: "pointer" }}>
          <span>📦 予備品管理</span>
          <strong>{spareRows.length}</strong>
        </div>

        <div className="card" onClick={() => setPage("calendar")} style={{ cursor: "pointer" }}>
          <span>📅 カレンダー</span>
          <strong>{unifiedCalendarEvents.length}</strong>
        </div>

        <div className="card" onClick={() => setPage("work")} style={{ cursor: "pointer" }}>
          <span>🏗️ 計画工事</span>
          <strong>{plannedWorks.length}</strong>
        </div>
      </div>
    </>
  );
}


  function formatMaintenanceDate(value) {
    if (!value) return "";

    if (typeof value === "number") {
      const date = XLSX.SSF.parse_date_code(value);
      if (!date) return "";
      return `${date.y}-${String(date.m).padStart(2, "0")}-${String(date.d).padStart(2, "0")}`;
    }

    if (value instanceof Date) {
      return toLocalDateText(value);
    }

    const text = String(value).trim();
    if (!text) return "";

    const parsed = new Date(text.replace(/\./g, "/").replace(/-/g, "/"));
    if (!Number.isNaN(parsed.getTime())) {
      return parsed.toISOString().slice(0, 10);
    }

    return text.replace(/\//g, "-").slice(0, 10);
  }

  function guessMaintenanceTypeFromText(value) {
    const textValue = String(value || "");
    if (textValue.includes("給油") || textValue.includes("グリス")) return "給油";
    if (textValue.includes("交換")) return "交換";
    if (textValue.includes("清掃")) return "清掃";
    if (textValue.includes("調整")) return "調整";
    if (textValue.includes("校正")) return "校正";
    if (textValue.includes("修理")) return "修理";
    return "点検";
  }

  function getMaintenanceCycleDaysFromText(value) {
    if (value === undefined || value === null || value === "") return "";
    const textValue = String(value).trim();
    if (!textValue) return "";

    if (/^\d+$/.test(textValue)) {
      const num = Number(textValue);
      return num > 10000 ? "" : num;
    }

    const year = textValue.match(/(\d+)\s*年/);
    const month = textValue.match(/(\d+)\s*月/);
    const day = textValue.match(/(\d+)\s*日/);

    const total =
      (year ? Number(year[1]) * 365 : 0) +
      (month ? Number(month[1]) * 30 : 0) +
      (day ? Number(day[1]) : 0);

    return total || "";
  }

  function buildMaintenanceFromScheduleRow(row, sheetName, fileName) {
    const machineNo = row?.[1] || "";
    const equipment1 = row?.[2] || "";
    const equipment2 = row?.[3] || "";
    const partName = row?.[4] || "";
    const detail = row?.[5] || "";
    const year = Number(row?.[6] || 0);
    const month = Number(row?.[7] || 0);
    const day = Number(row?.[8] || 0);
    const prepDays = row?.[9] || "";
    const nextDate = formatMaintenanceDate(row?.[10]);
    const lastDate = formatMaintenanceDate(row?.[12] || row?.[13]);
    const result = formatMaintenanceDate(row?.[13]) || String(row?.[13] || "");

    if (!machineNo && !equipment1 && !equipment2 && !partName && !detail) return null;
    if (String(machineNo).includes("生産機番名")) return null;

    const cycle = year * 365 + month * 30 + day;
    const maintenanceType = guessMaintenanceTypeFromText(`${detail} ${partName} ${equipment1} ${equipment2}`);

    return {
      equipment: String(equipment1 || equipment2 || machineNo || "").trim(),
      lineName: String(machineNo || "").trim(),
      equipment2Name: String(equipment2 || "").trim(),
      sectionName: "",
      partName: String(partName || equipment1 || "").trim(),
      partNo: "",
      serialNo: "",
      maker: "",
      price: "",
      supplier: "",
      purchaseUrl: "",
      location: "",
      locationRack: "",
      lot: "",
      shelf: "",
      box: "",
      address: "",
      leadTime: "",
      reorderPoint: "",
      reorderQty: "",
      category: "定期保全",
      maintenanceType,
      maintenanceDetail: String(detail || `${equipment1 || ""} ${equipment2 || ""}`).trim(),
      method: "",
      standard: "",
      responseAction: "",
      result: String(result || "").trim(),
      prepDays: String(prepDays || "").trim(),
      sourceSheet: sheetName || "",
      sourceFile: fileName || "",
      isMaintenanceTarget: true,
      cycle: cycle || "",
      lastDate,
      nextDate,
      owner: "",
      note: `Excel取込：${fileName || ""} / ${sheetName || ""}`,
      stockQty: 0,
      minStock: 1,
      stockNote: "",
      image: "",
      imageUrl: "",
    };
  }

  function getSheetCellText(rows, rowIndex, colIndex) {
    return String(rows?.[rowIndex]?.[colIndex] || "").trim();
  }

  function buildMaintenanceFromInspectionRow(row, rows, sheetName, fileName) {
    const no = row?.[0];
    const sectionName = row?.[1] || "";
    const item = row?.[2] || "";
    const method = row?.[3] || "";
    const standard = row?.[4] || "";
    const minutes = row?.[5] || "";
    const responseAction = row?.[6] || "";
    const cycleCell = row?.[7] || "";
    const result = row?.[8] || "";

    if (!sectionName && !item && !method && !standard) return null;
    if (String(no).includes("№") || String(sectionName).includes("部位")) return null;

    const equipmentText = [getSheetCellText(rows, 2, 2), getSheetCellText(rows, 3, 0)].join(" ");
    const makerText = getSheetCellText(rows, 3, 2);
    const equipment = equipmentText.replace("設備名：", "").trim() || sheetName;
    const maker = makerText.replace("メーカ：", "").trim();
    const maintenanceType = guessMaintenanceTypeFromText(`${method} ${item} ${standard} ${responseAction}`);
    const cycle = getMaintenanceCycleDaysFromText(cycleCell);

    return {
      equipment,
      lineName: "",
      equipment2Name: sheetName,
      sectionName: String(sectionName || "").trim(),
      partName: String(sectionName || item || "").trim(),
      partNo: "",
      serialNo: "",
      maker,
      price: "",
      supplier: "",
      purchaseUrl: "",
      location: "",
      locationRack: "",
      lot: "",
      shelf: "",
      box: "",
      address: "",
      leadTime: "",
      reorderPoint: "",
      reorderQty: "",
      category: "定期点検",
      maintenanceType,
      maintenanceDetail: String(item || "").trim(),
      method: String(method || "").trim(),
      standard: String(standard || "").trim(),
      responseAction: String(responseAction || "").trim(),
      result: String(result || "").trim(),
      prepDays: "",
      requiredMinutes: String(minutes || "").trim(),
      cycleCount: String(cycleCell || "").trim(),
      sourceSheet: sheetName || "",
      sourceFile: fileName || "",
      isMaintenanceTarget: true,
      cycle: cycle || "",
      lastDate: "",
      nextDate: "",
      owner: "",
      note: `Excel取込：${fileName || ""} / ${sheetName || ""}`,
      stockQty: 0,
      minStock: 1,
      stockNote: "",
      image: "",
      imageUrl: "",
    };
  }

  const handleMaintenanceExcelUpload = async (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    let success = 0;
    let failed = 0;

    for (const file of files) {
      try {
        const data = await file.arrayBuffer();
        const workbook = XLSX.read(data, { cellDates: true });

        for (const sheetName of workbook.SheetNames) {
          const sheet = workbook.Sheets[sheetName];
          const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: true });
          const sheetText = rows.slice(0, 10).map((row) => (row || []).join(" ")).join(" ");

          if (sheetText.includes("定期保全リスト") || sheetText.includes("生産機番名")) {
            for (let r = 5; r < rows.length; r++) {
              const item = buildMaintenanceFromScheduleRow(rows[r], sheetName, file.name);
              if (!item) continue;
              await addDoc(collection(db, "parts"), item);
              success += 1;
            }
            continue;
          }

          if (sheetText.includes("定期点検") || sheetText.includes("整備基準") || sheetText.includes("部位 項目 方法")) {
            for (let r = 6; r < rows.length; r++) {
              const item = buildMaintenanceFromInspectionRow(rows[r], rows, sheetName, file.name);
              if (!item) continue;
              await addDoc(collection(db, "parts"), item);
              success += 1;
            }
          }
        }
      } catch (error) {
        console.error("Maintenance import error:", file.name, error);
        failed += 1;
      }
    }

    await loadParts();
    alert(`定期保全Excel取込完了\n成功：${success}件\n失敗：${failed}件`);
    e.target.value = "";
  };

  async function completeMaintenanceRow(row) {
    const todayValue = todayText();
    const nextDate = row.cycle ? addDays(todayValue, row.cycle) : "";

    await updateDoc(doc(db, "parts", row.id), {
      lastDate: todayValue,
      nextDate,
      result: "OK",
    });

    await loadParts();
    alert("実施完了にしました。次回日も更新しました。");
  }

  function renderMaintenance() {
    const typeOptions = ["全て", "交換", "点検", "給油", "清掃", "調整", "校正", "修理"];
    const over = maintenanceRows.filter((r) => r.status === "交換超過").length;
    const soon7 = maintenanceRows.filter((r) => r.daysLeft !== "" && r.daysLeft >= 0 && r.daysLeft <= 7).length;
    const soon30 = maintenanceRows.filter((r) => r.daysLeft !== "" && r.daysLeft > 7 && r.daysLeft <= 30).length;

    const typeColor = (type) => {
      if (type === "交換") return "#fee2e2";
      if (type === "点検") return "#dbeafe";
      if (type === "給油") return "#fef3c7";
      if (type === "清掃") return "#dcfce7";
      if (type === "調整") return "#e0e7ff";
      if (type === "校正") return "#f3e8ff";
      if (type === "修理") return "#ffe4e6";
      return "#f1f5f9";
    };

    const typeIcon = (type) => {
      if (type === "交換") return "🔴";
      if (type === "点検") return "🔵";
      if (type === "給油") return "🛢️";
      if (type === "清掃") return "🟢";
      if (type === "調整") return "🛠️";
      if (type === "校正") return "🟣";
      if (type === "修理") return "🔧";
      return "⚙️";
    };

    const urgencyLabel = (row) => {
      if (row.daysLeft === "") return "未入力";
      if (row.daysLeft < 0) return `期限超過 ${Math.abs(row.daysLeft)}日`;
      if (row.daysLeft === 0) return "本日実施";
      return `残り ${row.daysLeft}日`;
    };

    const urgencyStyle = (row) => {
      if (row.daysLeft === "") return { background: "#e5e7eb", color: "#334155" };
      if (row.daysLeft < 0) return { background: "#fee2e2", color: "#b91c1c" };
      if (row.daysLeft <= 7) return { background: "#ffedd5", color: "#c2410c" };
      if (row.daysLeft <= 30) return { background: "#fef3c7", color: "#a16207" };
      return { background: "#dcfce7", color: "#166534" };
    };

    return (
      <>
        <div className="header">
          <div>
            <h2>🔧 定期保全</h2>
            <p>交換・点検・給油を「どこで・何を・いつ・誰が」一目で分かるカード表示にしました。緊急順・ABC順・設備別で切替できます。</p>
          </div>
          <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
            <label className="primaryButton" style={{ cursor: "pointer" }}>
              📥 定期保全Excel取込
              <input
                type="file"
                accept=".xlsx,.xls,.xlsm"
                multiple
                onChange={handleMaintenanceExcelUpload}
                style={{ display: "none" }}
              />
            </label>
            <button className="primaryButton" onClick={addMaintenancePart}><Plus size={16} /> 新規追加</button>
            <button className="primaryButton" onClick={() => setPage("spare")}>📦 予備品から追加</button>
            <button
              className="deleteButton"
              onClick={async () => {
                if (!confirm("定期保全リストを空にしますか？予備品データは消えません。")) return;

                for (const row of parts) {
                  if (row.isMaintenanceTarget === true) {
                    await updateField("parts", row.id, "isMaintenanceTarget", false);
                  }
                }

                await loadParts();
                alert("定期保全リストを空にしました。予備品データは残っています。");
              }}
            >
              🧹 定期保全を空にする
            </button>
          </div>
        </div>

        <div className="cards" style={{ marginBottom: "18px" }}>
          <div className="card red"><span>期限超過</span><strong>{over}</strong></div>
          <div className="card yellow"><span>7日以内</span><strong>{soon7}</strong></div>
          <div className="card yellow"><span>30日以内</span><strong>{soon30}</strong></div>
          <div className="card"><span>表示件数</span><strong>{filteredMaintenanceRows.length}</strong></div>
        </div>

        <div className="tableWrap" style={{ marginBottom: "18px" }}>
          <h3>🔍 定期保全検索・並び替え</h3>
          <p>設備名・部位・内容・品番・担当者・保全種類で検索できます。</p>
          <div style={{ display: "grid", gridTemplateColumns: "1fr 180px 190px", gap: "10px", alignItems: "center" }}>
            <input
              value={maintenanceSearch}
              onChange={(e) => setMaintenanceSearch(e.target.value)}
              placeholder="例：76-060 給油 ボウルフィーダ 羽根田 SC-N4"
              style={{ fontSize: "18px", minHeight: "52px" }}
            />
            <select
              value={maintenanceTypeFilter}
              onChange={(e) => setMaintenanceTypeFilter(e.target.value)}
              style={{ minHeight: "52px", fontSize: "16px" }}
            >
              {typeOptions.map((type) => <option key={type} value={type}>{type}</option>)}
            </select>
            <select
              value={maintenanceSort}
              onChange={(e) => setMaintenanceSort(e.target.value)}
              style={{ minHeight: "52px", fontSize: "16px" }}
            >
              <option value="urgent">緊急順</option>
              <option value="az">ABC / あいうえお順</option>
              <option value="equipment">設備名順</option>
              <option value="type">保全種類順</option>
              <option value="owner">担当者順</option>
            </select>
          </div>
        </div>

        {maintenanceRows.length === 0 && (
          <div className="tableWrap">
            <div className="calendarEditCard">
              <h3>定期保全リストは空です。</h3>
              <p>Excel取込、手入力、または予備品管理の「🔧 定期保全へ追加」から登録できます。</p>
            </div>
          </div>
        )}

        <div style={{ display: "grid", gap: "18px" }}>
          {filteredMaintenanceRows.map((row) => (
            <div
              key={row.id}
              className="tableWrap"
              style={{
                borderLeft: row.daysLeft !== "" && row.daysLeft < 0 ? "8px solid #ef4444" : row.daysLeft !== "" && row.daysLeft <= 7 ? "8px solid #f97316" : "8px solid #2563eb",
                padding: "22px",
              }}
            >
              <div style={{ display: "flex", justifyContent: "space-between", gap: "16px", flexWrap: "wrap", alignItems: "flex-start" }}>
                <div style={{ flex: "1 1 520px" }}>
                  <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", alignItems: "center", marginBottom: "10px" }}>
                    <span style={{ padding: "8px 14px", borderRadius: "999px", fontWeight: "900", background: typeColor(row.maintenanceType || "交換") }}>
                      {typeIcon(row.maintenanceType || "交換")} {row.maintenanceType || "交換"}
                    </span>
                    <span style={{ padding: "8px 14px", borderRadius: "999px", fontWeight: "900", ...urgencyStyle(row) }}>
                      {urgencyLabel(row)}
                    </span>
                  </div>

                  <h2 style={{ fontSize: "30px", margin: "0 0 8px", color: "#0f172a" }}>
                    {row.equipment || row.lineName || "設備名なし"}
                  </h2>
                  <p style={{ fontSize: "20px", margin: "0 0 6px", color: "#2563eb", fontWeight: "800" }}>
                    {row.sectionName || row.equipment2Name || row.partName || "部位未入力"}
                  </p>
                  <p style={{ fontSize: "18px", margin: 0, color: "#475569", whiteSpace: "pre-wrap" }}>
                    {row.maintenanceDetail || "内容未入力"}
                  </p>
                </div>

                <div style={{ minWidth: "220px", textAlign: "right" }}>
                  <div style={{ fontSize: "14px", color: "#64748b" }}>次回実施日</div>
                  <div style={{ fontSize: "24px", fontWeight: "900" }}>{row.nextDate || "未入力"}</div>
                  <div style={{ fontSize: "14px", color: "#64748b", marginTop: "8px" }}>前回実施日</div>
                  <div style={{ fontSize: "18px", fontWeight: "700" }}>{row.lastDate || "未入力"}</div>
                </div>
              </div>

              <div className="reportGrid" style={{ marginTop: "18px" }}>
                <label>保全種類
                  <select value={row.maintenanceType || "交換"} onChange={(e) => updateField("parts", row.id, "maintenanceType", e.target.value)}>
                    {typeOptions.filter((type) => type !== "全て").map((type) => <option key={type} value={type}>{type}</option>)}
                  </select>
                </label>
                <label>生産機番<input value={row.lineName || ""} onChange={(e) => updateField("parts", row.id, "lineName", e.target.value)} /></label>
                <label>設備名<input value={row.equipment || ""} onChange={(e) => updateField("parts", row.id, "equipment", e.target.value)} /></label>
                <label>装置・部位<input value={row.sectionName || row.equipment2Name || row.partName || ""} onChange={(e) => updateField("parts", row.id, "sectionName", e.target.value)} /></label>
                <label>方法<input value={row.method || ""} onChange={(e) => updateField("parts", row.id, "method", e.target.value)} /></label>
                <label>周期(日)<input type="number" value={row.cycle || ""} onChange={(e) => updateField("parts", row.id, "cycle", e.target.value ? Number(e.target.value) : "")} /></label>
                <label>前回実施日<input type="date" value={row.lastDate || ""} onChange={(e) => updateField("parts", row.id, "lastDate", e.target.value)} /></label>
                <label>担当者<input value={row.owner || ""} onChange={(e) => updateField("parts", row.id, "owner", e.target.value)} /></label>
                <label>結果<input value={row.result || ""} onChange={(e) => updateField("parts", row.id, "result", e.target.value)} /></label>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "12px", marginTop: "12px" }}>
                <label style={{ fontWeight: "700" }}>内容
                  <textarea style={{ minHeight: "110px", fontSize: "16px" }} value={row.maintenanceDetail || ""} onChange={(e) => updateField("parts", row.id, "maintenanceDetail", e.target.value)} />
                </label>
                <label style={{ fontWeight: "700" }}>基準
                  <textarea style={{ minHeight: "110px", fontSize: "16px" }} value={row.standard || ""} onChange={(e) => updateField("parts", row.id, "standard", e.target.value)} />
                </label>
              </div>

              <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", marginTop: "16px" }}>
                <button className="primaryButton" onClick={() => completeMaintenanceRow(row)}>✅ 完了</button>
                <button className="primaryButton" onClick={() => setPage("calendar")}>📅 カレンダー確認</button>
                <button className="deleteButton" onClick={() => updateField("parts", row.id, "isMaintenanceTarget", false)}>定期保全から外す</button>
              </div>
            </div>
          ))}
        </div>
      </>
    );
  }


  function cleanPrice(value) {
    if (value === undefined || value === null) return "";
    return String(value)
      .replace(/[￥¥円]/g, "")
      .replace(/\s/g, "")
      .trim();
  }

  function normalizeNumberText(value) {
    if (value === undefined || value === null || value === "") return "";
    let text = String(value)
      .replace(/[￥¥円個]/g, "")
      .replace(/pcs/gi, "")
      .replace(/[^\d.,-]/g, "")
      .trim();

    if (!text) return "";

    // 200.000 / 1.190.801 / 1,190,801 を日本円の桁区切りとして正しく読む
    if (/^-?\d{1,3}(\.\d{3})+$/.test(text)) text = text.replace(/\./g, "");
    if (/^-?\d{1,3}(,\d{3})+(\.\d+)?$/.test(text)) text = text.replace(/,/g, "");

    // カンマ小数の書き方にも最低限対応
    if (/^-?\d+,\d+$/.test(text) && !text.includes(".")) text = text.replace(",", ".");

    return text;
  }

  function parseYen(value) {
    const text = normalizeNumberText(value);
    const num = Number(text);
    return Number.isFinite(num) ? num : 0;
  }

  function parseQty(value) {
    const text = normalizeNumberText(value);
    const num = Number(text);
    return Number.isFinite(num) ? num : 0;
  }

  function formatYen(value) {
    return `¥${Math.round(Number(value || 0)).toLocaleString()}`;
  }

  function makeSpareQuery(row) {
    return [row.partName, row.partNo || row.serialNo, row.maker, row.supplier]
      .filter(Boolean)
      .join(" ")
      .trim();
  }

  function makeSearchUrl(row, type = "image") {
    const query = makeSpareQuery(row) || row.partName || row.partNo || "";
    const encoded = encodeURIComponent(query);

    if (type === "image") return `https://www.google.com/search?tbm=isch&q=${encoded}`;
    if (type === "google") return `https://www.google.com/search?q=${encoded}`;
    if (type === "misumi") return `https://www.google.com/search?q=${encoded}%20site%3Ajp.misumi-ec.com`;
    if (type === "monotaro") return `https://www.monotaro.com/s/?c=&q=${encoded}`;
    if (type === "amazon") return `https://www.amazon.co.jp/s?k=${encoded}`;
    if (type === "yahoo") return `https://shopping.yahoo.co.jp/search?p=${encoded}`;
    if (type === "rakuten") return `https://search.rakuten.co.jp/search/mall/${encoded}/`;
    if (type === "askul") return `https://www.askul.co.jp/ksearch/?searchWord=${encoded}`;
    if (type === "nakanet") return `https://www.google.com/search?q=${encoded}%20site%3Ane-nakanet.co.jp`;
    if (type === "nakanetLogin") return `https://www.ne-nakanet.co.jp/nakanet/login`;

    if (type === "omron") return `https://www.google.com/search?q=${encoded}%20site%3Aomron.com%20OR%20site%3Aia.omron.com`;
    if (type === "smc") return `https://www.google.com/search?q=${encoded}%20site%3Asmcworld.com`;
    if (type === "keyence") return `https://www.google.com/search?q=${encoded}%20site%3Akeyence.co.jp`;
    if (type === "thk") return `https://www.google.com/search?q=${encoded}%20site%3Athk.com`;
    if (type === "ckd") return `https://www.google.com/search?q=${encoded}%20site%3Ackd.co.jp`;
    if (type === "iai") return `https://www.google.com/search?q=${encoded}%20site%3Aiai-robot.co.jp`;
    if (type === "panasonic") return `https://www.google.com/search?q=${encoded}%20site%3Aindustrial.panasonic.com`;

    return `https://www.google.com/search?q=${encoded}`;
  }

  function guessSupplier(row) {
    const maker = String(row.maker || "").toUpperCase();
    if (maker.includes("OMRON") || maker.includes("オムロン")) return "OMRON / MISUMI / MonotaRO";
    if (maker.includes("SMC")) return "SMC / MISUMI / MonotaRO";
    if (maker.includes("KEYENCE") || maker.includes("キーエンス")) return "KEYENCE";
    if (maker.includes("CKD")) return "CKD / MISUMI / MonotaRO";
    if (maker.includes("THK")) return "THK / MISUMI / MonotaRO";
    if (maker.includes("IAI")) return "IAI / MISUMI";
    if (maker.includes("PANASONIC") || maker.includes("パナソニック")) return "Panasonic / MISUMI / MonotaRO";
    if (maker.includes("FUJI") || maker.includes("富士")) return "Fuji Electric / MISUMI / MonotaRO";
    return "MISUMI / MonotaRO / Amazon / Yahoo / NAKANET";
  }

  async function smartFillSpare(row) {
    const query = makeSpareQuery(row);

    if (!query) {
      alert("部品名または型式を入力してください。");
      return;
    }

    const updates = {};

    if (!row.purchaseUrl) {
      updates.purchaseUrl = makeSearchUrl(row, "misumi");
    }

    if (!row.supplier) {
      updates.supplier = guessSupplier(row);
    }

    if (!row.stockNote) {
      updates.stockNote = [
        `AI補完候補：${query}`,
        "",
        "確認リンク候補：",
        `画像検索: ${makeSearchUrl(row, "image")}`,
        `MISUMI: ${makeSearchUrl(row, "misumi")}`,
        `MonotaRO: ${makeSearchUrl(row, "monotaro")}`,
        `Amazon: ${makeSearchUrl(row, "amazon")}`,
        `Yahoo: ${makeSearchUrl(row, "yahoo")}`,
        `楽天: ${makeSearchUrl(row, "rakuten")}`,
        `NAKANET: ${makeSearchUrl(row, "nakanet")}`,
        "",
        "写真は画像検索から画像URLをコピーして貼り付け、または写真ファイルをアップロードしてください。",
      ].join("\n");
    }

    for (const [field, value] of Object.entries(updates)) {
      await updateField("parts", row.id, field, value);
    }

    window.open(makeSearchUrl(row, "image"), "_blank");
    setTimeout(() => window.open(makeSearchUrl(row, "misumi"), "_blank"), 250);
    setTimeout(() => window.open(makeSearchUrl(row, "monotaro"), "_blank"), 500);

    alert("AI補完しました。画像検索・MISUMI・MonotaROを開きました。必要な写真URLや購入URLを確認して貼り付けてください。");
  }

  function findHeaderIndex(rows, names) {
    for (let r = 0; r < Math.min(rows.length, 12); r++) {
      const rowText = (rows[r] || []).map((v) => String(v || "")).join(" ");
      if (names.every((name) => rowText.includes(name))) return r;
    }
    return -1;
  }

  function findColumn(rows, headerRowIndex, candidates) {
    const start = Math.max(0, headerRowIndex - 1);
    const end = Math.min(rows.length - 1, headerRowIndex + 1);

    for (let r = start; r <= end; r++) {
      const row = rows[r] || [];
      for (let c = 0; c < row.length; c++) {
        const cell = String(row[c] || "").replace(/\s/g, "");
        if (candidates.some((candidate) => cell.includes(candidate.replace(/\s/g, "")))) {
          return c;
        }
      }
    }
    return -1;
  }

  function getCell(row, index) {
    if (index < 0) return "";
    return row?.[index] ?? "";
  }

  function buildSparePartFromRow(row, col, sheetName) {
    const partName = getCell(row, col.partName);
    const partNo = getCell(row, col.partNo);

    if (!partName || String(partName).includes("品名")) return null;
    if (!partNo && !getCell(row, col.maker)) return null;

    const locationParts = [
      getCell(row, col.location),
      getCell(row, col.locationRack),
      getCell(row, col.lot),
      getCell(row, col.shelf),
      getCell(row, col.box),
      getCell(row, col.address),
    ].filter(Boolean);

    return {
      equipment: "",
      lineName: "",
      partName: String(partName || "").trim(),
      partNo: String(partNo || "").trim(),
      serialNo: String(partNo || "").trim(),
      maker: String(getCell(row, col.maker) || "").trim(),
      price: cleanPrice(getCell(row, col.price)),
      supplier: String(getCell(row, col.supplier) || "").trim(),
      purchaseUrl: "",
      imageUrl: "",
      location: locationParts.join(" / "),
      locationRack: String(getCell(row, col.locationRack) || getCell(row, col.location) || "").trim(),
      lot: String(getCell(row, col.lot) || "").trim(),
      shelf: String(getCell(row, col.shelf) || "").trim(),
      box: String(getCell(row, col.box) || "").trim(),
      address: String(getCell(row, col.address) || "").trim(),
      leadTime: String(getCell(row, col.leadTime) || "").trim(),
      reorderPoint: String(getCell(row, col.reorderPoint) || "").trim(),
      reorderQty: String(getCell(row, col.reorderQty) || "").trim(),
      stockQty: Number(getCell(row, col.stockQty) || 0),
      minStock: Number(getCell(row, col.reorderPoint) || 1),
      cycle: 90,
      lastDate: "",
      owner: "",
      category: sheetName || "予備品",
      isMaintenanceTarget: false,
      note: String(getCell(row, col.note) || "").trim(),
      stockNote: String(getCell(row, col.note) || "").trim(),
      image: "",
    };
  }

  const handleSpareExcelUpload = async (e) => {
    const files = Array.from(e.target.files || []);
    if (files.length === 0) return;

    let success = 0;
    let failed = 0;

    for (const file of files) {
      try {
        const data = await file.arrayBuffer();
        const workbook = XLSX.read(data);

        for (const sheetName of workbook.SheetNames) {
          const sheet = workbook.Sheets[sheetName];
          const rows = XLSX.utils.sheet_to_json(sheet, { header: 1, raw: false });
          const headerRowIndex = findHeaderIndex(rows, ["品名", "型式"]);
          if (headerRowIndex < 0) continue;

          const col = {
            partName: findColumn(rows, headerRowIndex, ["品名"]),
            partNo: findColumn(rows, headerRowIndex, ["型式", "図番", "型式・図番"]),
            maker: findColumn(rows, headerRowIndex, ["メーカ", "メーカー"]),
            leadTime: findColumn(rows, headerRowIndex, ["購入L/T", "購入LT", "LT", "納期"]),
            price: findColumn(rows, headerRowIndex, ["単価", "価格"]),
            reorderPoint: findColumn(rows, headerRowIndex, ["発注点", "最低在庫"]),
            reorderQty: findColumn(rows, headerRowIndex, ["発注数", "発注量"]),
            supplier: findColumn(rows, headerRowIndex, ["発注先", "購入先"]),
            location: findColumn(rows, headerRowIndex, ["所番地", "ロケ"]),
            locationRack: findColumn(rows, headerRowIndex, ["ロケ"]),
            lot: findColumn(rows, headerRowIndex, ["ロット"]),
            shelf: findColumn(rows, headerRowIndex, ["棚段", "棚"]),
            box: findColumn(rows, headerRowIndex, ["箱"]),
            address: findColumn(rows, headerRowIndex, ["番地"]),
            note: findColumn(rows, headerRowIndex, ["備考", "メモ"]),
            stockQty: findColumn(rows, headerRowIndex, ["在庫", "現在在庫"]),
          };

          for (let r = headerRowIndex + 1; r < rows.length; r++) {
            const part = buildSparePartFromRow(rows[r], col, sheetName);
            if (!part) continue;
            await addDoc(collection(db, "parts"), part);
            success += 1;
          }
        }
      } catch (error) {
        console.error("Spare import error:", file.name, error);
        failed += 1;
      }
    }

    await loadParts();
    alert(`予備品Excel取込完了\n成功：${success}件\n失敗：${failed}件`);
  };


  function guessMakerFromText(value) {
    const text = String(value || "").toUpperCase();

    if (text.includes("OMRON") || text.includes("オムロン") || text.includes("E2")) return "OMRON";
    if (text.includes("SMC") || text.includes("CDQ") || text.includes("CDJ") || text.includes("CQ2")) return "SMC";
    if (text.includes("KEYENCE") || text.includes("キーエンス") || text.includes("FU-") || text.includes("PZ-") || text.includes("LV-")) return "KEYENCE";
    if (text.includes("CKD")) return "CKD";
    if (text.includes("IAI") || text.includes("RCP") || text.includes("PCON")) return "IAI";
    if (text.includes("PANASONIC") || text.includes("パナソニック")) return "Panasonic";
    if (text.includes("THK")) return "THK";
    if (text.includes("FUJI") || text.includes("富士") || text.includes("SC-N") || text.includes("SC80")) return "Fuji Electric";

    return "";
  }

  function buildSpareAiPreview(value) {
    const raw = String(value || "").trim();
    if (!raw) return null;

    const tokens = raw.split(/\s+/).filter(Boolean);
    const maker = guessMakerFromText(raw);
    const partNoCandidate = tokens.find((token) => /[A-Za-z0-9]/.test(token) && /[-0-9]/.test(token)) || "";
    const partNameCandidate = tokens.filter((token) => token !== maker && token !== partNoCandidate).join(" ") || raw;

    const previewRow = {
      partName: partNameCandidate,
      partNo: partNoCandidate,
      serialNo: partNoCandidate,
      maker,
      supplier: maker ? guessSupplier({ maker }) : "MISUMI / MonotaRO / Amazon / Yahoo / NAKANET",
    };

    const stockAdvice = "最低在庫はまず1〜2個で開始し、使用頻度が高い部品は3個以上に調整してください。";

    return {
      ...previewRow,
      stockAdvice,
      imageUrl: makeSearchUrl(previewRow, "image"),
      googleUrl: makeSearchUrl(previewRow, "google"),
      misumiUrl: makeSearchUrl(previewRow, "misumi"),
      monotaroUrl: makeSearchUrl(previewRow, "monotaro"),
      amazonUrl: makeSearchUrl(previewRow, "amazon"),
      yahooUrl: makeSearchUrl(previewRow, "yahoo"),
      rakutenUrl: makeSearchUrl(previewRow, "rakuten"),
      nakanetUrl: makeSearchUrl(previewRow, "nakanet"),
      omronUrl: makeSearchUrl(previewRow, "omron"),
      smcUrl: makeSearchUrl(previewRow, "smc"),
      keyenceUrl: makeSearchUrl(previewRow, "keyence"),
    };
  }

  async function createSpareFromAiPreview() {
    const preview = spareAiPreview || buildSpareAiPreview(spareAiInput);

    if (!preview) {
      alert("部品名または型式を入力してください。例：OMRON E2NC-EA21");
      return;
    }

    await addDoc(collection(db, "parts"), {
      equipment: "",
      lineName: "",
      partName: preview.partName || "",
      partNo: preview.partNo || "",
      serialNo: preview.serialNo || preview.partNo || "",
      maker: preview.maker || "",
      price: "",
      supplier: preview.supplier || "",
      purchaseUrl: preview.misumiUrl || preview.googleUrl || "",
      imageUrl: "",
      location: "",
      locationRack: "",
      lot: "",
      shelf: "",
      box: "",
      address: "",
      leadTime: "",
      reorderPoint: "1",
      reorderQty: "1",
      category: "AI補完",
      isMaintenanceTarget: false,
      cycle: 90,
      lastDate: "",
      owner: "",
      note: "",
      stockQty: 0,
      minStock: 1,
      stockNote: [
        "AI部品アシスタントで作成。内容確認後、必要に応じて編集してください。",
        `画像検索: ${preview.imageUrl}`,
        `MISUMI: ${preview.misumiUrl}`,
        `MonotaRO: ${preview.monotaroUrl}`,
        `Amazon: ${preview.amazonUrl}`,
        `Yahoo: ${preview.yahooUrl}`,
        `楽天: ${preview.rakutenUrl}`,
        `NAKANET: ${preview.nakanetUrl}`,
      ].join("\n"),
      image: sparePhotoImage || "",
    });

    setSpareSearch(preview.partNo || preview.partName || spareAiInput);
    setSpareAiInput("");
    setSpareAiPreview(null);
    setSparePhotoImage("");
    setSparePhotoOcrText("");
    setOcrCandidates([]);
    await loadParts();
    alert("AI候補から予備品を追加しました。写真URL・価格・保管場所・使用設備を確認して編集してください。");
  }


  function extractPartCandidates(text) {
    const cleaned = String(text || "")
      .replace(/[｜|]/g, " ")
      .replace(/[‐‑–—]/g, "-")
      .replace(/\s+/g, " ")
      .toUpperCase();

    const patterns = [
      /[A-Z]{1,5}-[A-Z0-9]{1,8}(?:\/[A-Z0-9]{1,8})?(?:\s?\[[0-9A-Z]+\])?/g,
      /[A-Z]{2,}[0-9]{1,}[A-Z0-9-]{1,}/g,
      /[0-9][A-Z]{2}[0-9][A-Z0-9]{2,}/g,
      /[A-Z0-9]{2,}(?:[-\/][A-Z0-9\[\]]+)+/g,
    ];

    const candidates = [];

    patterns.forEach((pattern) => {
      const found = cleaned.match(pattern) || [];
      found.forEach((item) => {
        const value = item
          .replace(/\s+/g, " ")
          .replace(/[^A-Z0-9\-\/\[\] ]/g, "")
          .trim();

        if (value.length >= 4 && value.length <= 30 && /[0-9]/.test(value)) {
          candidates.push(value);
        }
      });
    });

    if (cleaned.includes("FUJI") || cleaned.includes("FUJI ELECTRIC")) candidates.unshift("Fuji Electric");
    if (cleaned.includes("OMRON") || cleaned.includes("オムロン")) candidates.unshift("OMRON");
    if (cleaned.includes("SMC")) candidates.unshift("SMC");
    if (cleaned.includes("KEYENCE") || cleaned.includes("キーエンス")) candidates.unshift("KEYENCE");

    return [...new Set(candidates)].slice(0, 12);
  }

  function applyOcrCandidate(candidate) {
    const candidateText = String(candidate || "").trim();
    if (!candidateText) return;

    const baseText = `${sparePhotoOcrText || ""} ${candidateText}`;
    const maker = guessMakerFromText(baseText) || guessMakerFromText(candidateText);
    const isMakerOnly = !/[0-9]/.test(candidateText);
    const partNo = isMakerOnly ? "" : candidateText;
    const partName = maker
      ? maker.includes("Fuji")
        ? "電磁接触器"
        : `${maker} 部品`
      : "写真AI読取部品";

    const previewRow = {
      partName,
      partNo,
      serialNo: partNo,
      maker,
      supplier: maker ? guessSupplier({ maker }) : "購入先確認",
    };

    const preview = {
      ...previewRow,
      stockAdvice: "AI検出候補から作成しました。内容を確認してから登録してください。",
      imageUrl: makeSearchUrl(previewRow, "image"),
      googleUrl: makeSearchUrl(previewRow, "google"),
      misumiUrl: makeSearchUrl(previewRow, "misumi"),
      monotaroUrl: makeSearchUrl(previewRow, "monotaro"),
      amazonUrl: makeSearchUrl(previewRow, "amazon"),
      yahooUrl: makeSearchUrl(previewRow, "yahoo"),
      rakutenUrl: makeSearchUrl(previewRow, "rakuten"),
      nakanetUrl: makeSearchUrl(previewRow, "nakanet"),
      omronUrl: makeSearchUrl(previewRow, "omron"),
      smcUrl: makeSearchUrl(previewRow, "smc"),
      keyenceUrl: makeSearchUrl(previewRow, "keyence"),
      ocrText: sparePhotoOcrText || "",
    };

    setSpareAiInput(`${maker} ${partNo}`.trim() || candidateText);
    setSpareAiPreview(preview);
  }

  async function handlePhotoPartRegister(e) {
    const file = e.target.files?.[0];
    if (!file) return;

    try {
      setSparePhotoLoading(true);
      setSparePhotoOcrText("");

      const imageBase64 = await new Promise((resolve, reject) => {
        const reader = new FileReader();
        reader.onloadend = () => resolve(reader.result);
        reader.onerror = reject;
        reader.readAsDataURL(file);
      });

      setSparePhotoImage(imageBase64);

      const result = await Tesseract.recognize(file, "eng+jpn", {
        logger: (message) => console.log("OCR", message),
      });

      const rawText = result?.data?.text || "";

      const cleanedText = rawText
        .replace(/[|｜]/g, " ")
        .replace(/[^\w\-ぁ-んァ-ン一-龥]/g, " ")
        .replace(/_/g, " ")
        .replace(/\s+/g, " ")
        .trim();

      if (!cleanedText) {
        alert("文字を読み取れませんでした。もう少し明るく、ラベルを近くで撮影してください。");
        return;
      }

      const candidates = extractPartCandidates(cleanedText);
      setOcrCandidates(candidates);

      const maker = guessMakerFromText(cleanedText);
      const partNo = candidates.find((item) => /[0-9]/.test(item) && !item.includes("FUJI") && !item.includes("OMRON") && !item.includes("SMC") && !item.includes("KEYENCE")) || "";

      const partName = maker
        ? maker.includes("Fuji")
          ? "電磁接触器"
          : `${maker} 部品`
        : partNo
          ? "写真AI読取部品"
          : "写真AI読取部品";

      const previewRow = {
        partName,
        partNo,
        serialNo: partNo,
        maker,
        supplier: maker ? guessSupplier({ maker }) : "購入先確認",
      };

      const preview = {
        ...previewRow,
        stockAdvice: "OCR読取結果を確認してから登録してください。間違いがあれば編集できます。",
        imageUrl: makeSearchUrl(previewRow, "image"),
        googleUrl: makeSearchUrl(previewRow, "google"),
        misumiUrl: makeSearchUrl(previewRow, "misumi"),
        monotaroUrl: makeSearchUrl(previewRow, "monotaro"),
        amazonUrl: makeSearchUrl(previewRow, "amazon"),
        yahooUrl: makeSearchUrl(previewRow, "yahoo"),
        rakutenUrl: makeSearchUrl(previewRow, "rakuten"),
        nakanetUrl: makeSearchUrl(previewRow, "nakanet"),
        omronUrl: makeSearchUrl(previewRow, "omron"),
        smcUrl: makeSearchUrl(previewRow, "smc"),
        keyenceUrl: makeSearchUrl(previewRow, "keyence"),
        ocrText: cleanedText,
      };

      setSpareAiInput(`${maker} ${partNo}`.trim() || cleanedText);
      setSpareAiPreview(preview);
      setSparePhotoOcrText(cleanedText);

      alert("写真解析完了。内容を確認してから登録してください。");
    } catch (error) {
      console.error("Photo OCR error:", error);
      alert("写真AI解析でエラーが発生しました。写真を変えてもう一度試してください。");
    } finally {
      setSparePhotoLoading(false);
      e.target.value = "";
    }
  }

  function renderSpareAiAssistant() {
    const preview = spareAiPreview || buildSpareAiPreview(spareAiInput);

    return (
      <div className="tableWrap" style={{ marginBottom: "18px", border: "2px solid #2563eb" }}>
        <h3>🤖 AI部品アシスタント</h3>
        <p>
          部品名・型式・メーカーを入力、または部品ラベルを写真で撮影すると、メーカー候補・購入先候補・画像検索・主要サイト検索をまとめて準備します。
        </p>

        <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", alignItems: "center" }}>
          <input
            value={spareAiInput}
            onChange={(e) => {
              setSpareAiInput(e.target.value);
              setSpareAiPreview(buildSpareAiPreview(e.target.value));
            }}
            placeholder="例：OMRON E2NC-EA21 / SMC CDQ2B16-20D / KEYENCE FU-35FA"
            style={{ fontSize: "18px", minHeight: "52px", flex: "1 1 420px" }}
          />
          <button
            className="primaryButton"
            onClick={() => setSpareAiPreview(buildSpareAiPreview(spareAiInput))}
          >
            🤖 候補作成
          </button>

          <label className="primaryButton" style={{ cursor: "pointer" }}>
            📷 写真AI登録
            <input
              type="file"
              accept="image/*"
              capture="environment"
              onChange={handlePhotoPartRegister}
              style={{ display: "none" }}
            />
          </label>

          <button className="primaryButton" onClick={createSpareFromAiPreview}>
            <Plus size={16} /> 候補から予備品追加
          </button>

          <button
            className="deleteButton"
            onClick={() => {
              setSpareAiInput("");
              setSpareAiPreview(null);
              setSparePhotoImage("");
              setSparePhotoOcrText("");
              setOcrCandidates([]);
            }}
          >
            キャンセル
          </button>
        </div>

        {sparePhotoLoading && (
          <div className="calendarEditCard" style={{ marginTop: "14px", border: "1px solid #2563eb" }}>
            <h3>📷 写真AI解析中...</h3>
            <p>ラベル文字を読み取っています。少し待ってください。</p>
          </div>
        )}

        {sparePhotoOcrText && (
          <div className="calendarEditCard" style={{ marginTop: "14px" }}>
            <h3>OCR読取結果</h3>
            <p style={{ color: "#64748b" }}>
              読み取った文字から、メーカー・型式候補だけを上の候補に反映しました。必要なら内容を編集してから登録してください。
            </p>
            <details>
              <summary style={{ cursor: "pointer", fontWeight: "bold" }}>読取テキストを見る</summary>
              <p style={{ whiteSpace: "pre-wrap", marginTop: "10px" }}>{sparePhotoOcrText}</p>
            </details>
          </div>
        )}

        {ocrCandidates.length > 0 && (
          <div className="calendarEditCard" style={{ marginTop: "14px", border: "1px solid #93c5fd" }}>
            <h3>🔍 AI検出候補</h3>
            <p style={{ color: "#64748b" }}>
              写真から読めた候補です。正しい品番・メーカーを押すと、下の登録候補に反映されます。
            </p>
            <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", marginTop: "10px" }}>
              {ocrCandidates.map((candidate) => (
                <button
                  key={candidate}
                  className="primaryButton"
                  onClick={() => applyOcrCandidate(candidate)}
                >
                  {candidate}
                </button>
              ))}
            </div>
          </div>
        )}

        {preview && (
          <div
            className="calendarEditCard"
            style={{
              marginTop: "14px",
              display: "grid",
              gridTemplateColumns: "180px 1fr",
              gap: "18px",
              alignItems: "start",
            }}
          >
            <div
              style={{
                height: "170px",
                borderRadius: "16px",
                background: "#f8fafc",
                border: "1px solid #dbe3ef",
                display: "flex",
                alignItems: "center",
                justifyContent: "center",
                fontSize: "48px",
                overflow: "hidden",
              }}
            >
              {sparePhotoImage ? (
                <img
                  src={sparePhotoImage}
                  alt="OCR preview"
                  style={{ width: "100%", height: "100%", objectFit: "contain" }}
                />
              ) : (
                "📷"
              )}
            </div>

            <div>
              <h2 style={{ margin: "0 0 6px", fontSize: "26px" }}>{preview.partName || "部品名候補なし"}</h2>
              <p style={{ margin: "0 0 6px", fontSize: "20px", fontWeight: "bold", color: "#2563eb" }}>
                型式・品番：{preview.partNo || "未検出"}
              </p>
              <p style={{ margin: "0 0 10px", color: "#475569" }}>
                メーカー候補：{preview.maker || "未検出"}　/　購入先候補：{preview.supplier}
              </p>
              <p style={{ color: "#64748b" }}>{preview.stockAdvice}</p>

              <div style={{ display: "flex", gap: "8px", flexWrap: "wrap", marginTop: "10px" }}>
                <button className="primaryButton" onClick={() => window.open(preview.imageUrl, "_blank")}>画像検索</button>
                <button className="primaryButton" onClick={() => window.open(preview.misumiUrl, "_blank")}>MISUMI</button>
                <button className="primaryButton" onClick={() => window.open(preview.monotaroUrl, "_blank")}>MonotaRO</button>
                <button className="primaryButton" onClick={() => window.open(preview.amazonUrl, "_blank")}>Amazon</button>
                <button className="primaryButton" onClick={() => window.open(preview.yahooUrl, "_blank")}>Yahoo</button>
                <button className="primaryButton" onClick={() => window.open(preview.rakutenUrl, "_blank")}>楽天</button>
                <button className="primaryButton" onClick={() => window.open(preview.nakanetUrl, "_blank")}>NAKANET</button>
              </div>
            </div>
          </div>
        )}
      </div>
    );
  }

  function renderSpareParts() {
    const stockSummary = spareRows.reduce(
      (sum, row) => {
        const price = parseYen(row.price);
        const qty = parseQty(row.stockQty);
        const minStock = parseQty(row.minStock || row.reorderPoint || 1) || 1;
        const reorderQty = parseQty(row.reorderQty);

        if (price > 0) sum.priceRegistered += 1;
        if (qty <= 0) sum.noStock += 1;
        if (qty > 0 && qty <= minStock) sum.warningStock += 1;

        if (price > 0 && qty > 0) {
          sum.totalStockValue += price * qty;
        }

        if (price > 0 && qty < minStock) {
          const needQty = reorderQty > 0 ? reorderQty : Math.max(0, minStock - qty);
          sum.orderPlanValue += price * needQty;
          sum.orderNeedCount += 1;
        }

        return sum;
      },
      {
        totalStockValue: 0,
        orderPlanValue: 0,
        priceRegistered: 0,
        noStock: 0,
        warningStock: 0,
        orderNeedCount: 0,
      }
    );

    const searched = spareSearch.trim().length > 0;
    const rowsToShow = searched ? filteredSpareRows : filteredSpareRows.slice(0, 30);

    return (
      <>
        <div className="header">
          <div>
            <h2>📦 予備品管理</h2>
            <p>Amazon・MISUMI風に、写真・型式・メーカー・購入先・使用設備・在庫を大きく見やすく表示します。</p>
          </div>
          <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
            <label className="primaryButton" style={{ cursor: "pointer" }}>
              📥 Excel取込
              <input
                type="file"
                accept=".xlsx,.xls,.xlsm"
                multiple
                onChange={handleSpareExcelUpload}
                style={{ display: "none" }}
              />
            </label>
            <button className="primaryButton" onClick={addPart}><Plus size={16} /> 予備品追加</button>
          </div>
        </div>

        <div className="cards" style={{ marginBottom: "18px" }}>
          <div className="card">
            <span>登録部品</span>
            <strong>{spareRows.length}</strong>
          </div>

          <div className="card red">
            <span>在庫なし</span>
            <strong>{stockSummary.noStock}</strong>
          </div>

          <div className="card yellow">
            <span>在庫注意</span>
            <strong>{stockSummary.warningStock}</strong>
          </div>

          <div className="card">
            <span>価格登録済み</span>
            <strong>{stockSummary.priceRegistered}</strong>
          </div>

          <div className="card">
            <span>在庫総額</span>
            <strong className="moneyText">{formatYen(stockSummary.totalStockValue)}</strong>
          </div>

          <div className="card yellow">
            <span>発注予定額</span>
            <strong className="moneyText">{formatYen(stockSummary.orderPlanValue)}</strong>
          </div>
        </div>

        {renderSpareAiAssistant()}

        <div className="tableWrap" style={{ marginBottom: "18px" }}>
          <h3>🔍 予備品AI検索</h3>
          <p>部品名・型式・メーカー・購入先・設備名・保管場所から検索できます。検索すると商品カードを大きく表示します。</p>
          <input
            value={spareSearch}
            onChange={(e) => setSpareSearch(e.target.value)}
            placeholder="例：OMRON E2NC センサー 76-060 SS2 中西電機"
            style={{ fontSize: "20px", minHeight: "54px" }}
          />
          <p style={{ color: "#64748b", marginTop: "10px" }}>
            表示：{rowsToShow.length}件 / 検索結果：{filteredSpareRows.length}件
          </p>
        </div>

        {rowsToShow.map((row) => (
          <div
            key={row.id}
            className="tableWrap"
            style={{
              display: "grid",
              gridTemplateColumns: "320px 1fr",
              gap: "24px",
              marginBottom: "22px",
              alignItems: "start",
            }}
          >
            <div style={{ textAlign: "center" }}>
              {row.image || row.imageUrl ? (
                <img
                  src={row.image || row.imageUrl}
                  alt=""
                  style={{
                    width: "300px",
                    height: "300px",
                    objectFit: "contain",
                    borderRadius: "18px",
                    border: "1px solid #dbe3ef",
                    background: "#f8fafc",
                  }}
                />
              ) : (
                <div
                  style={{
                    width: "300px",
                    height: "300px",
                    borderRadius: "18px",
                    border: "1px solid #dbe3ef",
                    background: "#f8fafc",
                    display: "flex",
                    alignItems: "center",
                    justifyContent: "center",
                    color: "#94a3b8",
                    margin: "0 auto",
                  }}
                >
                  写真なし
                </div>
              )}

              <input
                type="file"
                accept="image/*"
                onChange={(e) => handleImageUpload(e, "parts", row.id)}
                style={{ marginTop: "10px" }}
              />

              <input
                placeholder="画像URLを貼り付け"
                value={row.imageUrl || ""}
                onChange={(e) => updateField("parts", row.id, "imageUrl", e.target.value)}
                style={{ marginTop: "10px" }}
              />
            </div>

            <div>
              <div style={{ display: "flex", justifyContent: "space-between", gap: "12px", flexWrap: "wrap" }}>
                <div>
                  <h2 style={{ fontSize: "34px", margin: "0 0 10px", color: "#0f172a", lineHeight: 1.25, wordBreak: "break-word" }}>
                    {row.partName || "部品名なし"}
                  </h2>
                  <p style={{ fontSize: "20px", fontWeight: "bold", color: "#2563eb", margin: 0 }}>
                    型式・品番：{row.partNo || row.serialNo || "-"}
                  </p>
                  <p style={{ fontSize: "18px", color: "#475569" }}>
                    メーカー：{row.maker || "-"}　/　カテゴリ：{row.category || "-"}　/　定期保全：{row.isMaintenanceTarget ? "対象" : "未登録"}
                  </p>
                </div>

                <div style={{ textAlign: "right" }}>
                  <div style={{ fontSize: "16px", color: "#64748b" }}>在庫状態</div>
                  <div style={{ fontSize: "26px", fontWeight: "900" }}>{row.stockStatus}</div>
                  <div style={{ fontSize: "18px" }}>在庫：{row.stockQty || 0} / 最低：{row.minStock || 1}</div>
                </div>
              </div>

              <div className="reportGrid" style={{ marginTop: "16px" }}>
                <label>部品名<input value={row.partName || ""} onChange={(e) => updateField("parts", row.id, "partName", e.target.value)} /></label>
                <label>型式・品番<input value={row.partNo || row.serialNo || ""} onChange={(e) => { updateField("parts", row.id, "partNo", e.target.value); updateField("parts", row.id, "serialNo", e.target.value); }} /></label>
                <label>メーカー<input value={row.maker || ""} onChange={(e) => updateField("parts", row.id, "maker", e.target.value)} /></label>
                <label>価格<input value={row.price || ""} onChange={(e) => updateField("parts", row.id, "price", e.target.value)} /></label>
                <label>購入先<input value={row.supplier || ""} onChange={(e) => updateField("parts", row.id, "supplier", e.target.value)} /></label>
                <label>購入URL<input value={row.purchaseUrl || ""} onChange={(e) => updateField("parts", row.id, "purchaseUrl", e.target.value)} /></label>
                <label>使用設備<input value={row.equipment || ""} onChange={(e) => updateField("parts", row.id, "equipment", e.target.value)} /></label>
                <label>ライン<input value={row.lineName || ""} onChange={(e) => updateField("parts", row.id, "lineName", e.target.value)} /></label>
                <label>保管場所<input value={row.location || row.locationRack || ""} onChange={(e) => { updateField("parts", row.id, "location", e.target.value); updateField("parts", row.id, "locationRack", e.target.value); }} /></label>
                <label>在庫数<input type="number" value={row.stockQty || 0} onChange={(e) => updateField("parts", row.id, "stockQty", e.target.value)} /></label>
                <label>最低在庫<input type="number" value={row.minStock || 1} onChange={(e) => updateField("parts", row.id, "minStock", e.target.value)} /></label>
                <label>納期<input value={row.leadTime || ""} onChange={(e) => updateField("parts", row.id, "leadTime", e.target.value)} /></label>
              </div>

              <h3>備考</h3>
              <textarea
                value={row.stockNote || row.note || ""}
                onChange={(e) => {
                  updateField("parts", row.id, "stockNote", e.target.value);
                  updateField("parts", row.id, "note", e.target.value);
                }}
              />

              <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", marginTop: "14px" }}>
                <button className="primaryButton" onClick={() => smartFillSpare(row)}>🤖 AI補完・画像検索</button>
                <button
                  className={row.isMaintenanceTarget ? "deleteButton" : "primaryButton"}
                  onClick={() => updateField("parts", row.id, "isMaintenanceTarget", !row.isMaintenanceTarget)}
                >
                  {row.isMaintenanceTarget ? "定期保全から外す" : "🔧 定期保全へ追加"}
                </button>
                <button className="primaryButton" onClick={() => window.open(makeSearchUrl(row, "misumi"), "_blank")}>MISUMI検索</button>
                <button className="primaryButton" onClick={() => window.open(makeSearchUrl(row, "monotaro"), "_blank")}>MonotaRO検索</button>
                <button className="primaryButton" onClick={() => window.open(makeSearchUrl(row, "amazon"), "_blank")}>Amazon検索</button>
                <button className="primaryButton" onClick={() => window.open(makeSearchUrl(row, "yahoo"), "_blank")}>Yahoo検索</button>
                <button className="primaryButton" onClick={() => window.open(makeSearchUrl(row, "rakuten"), "_blank")}>楽天検索</button>
                <button className="primaryButton" onClick={() => window.open(makeSearchUrl(row, "nakanet"), "_blank")}>NAKANET検索</button>
                <button className="primaryButton" onClick={() => window.open(makeSearchUrl(row, "nakanetLogin"), "_blank")}>NAKANETログイン</button>
                <button className="primaryButton" onClick={() => window.open(makeSearchUrl(row, "askul"), "_blank")}>ASKUL検索</button>
                <button className="primaryButton" onClick={() => window.open(makeSearchUrl(row, "omron"), "_blank")}>OMRON検索</button>
                <button className="primaryButton" onClick={() => window.open(makeSearchUrl(row, "smc"), "_blank")}>SMC検索</button>
                <button className="primaryButton" onClick={() => window.open(makeSearchUrl(row, "keyence"), "_blank")}>KEYENCE検索</button>
                <button className="primaryButton" onClick={() => window.open(makeSearchUrl(row, "thk"), "_blank")}>THK検索</button>
                <button className="primaryButton" onClick={() => window.open(makeSearchUrl(row, "ckd"), "_blank")}>CKD検索</button>
                <button className="primaryButton" onClick={() => window.open(makeSearchUrl(row, "iai"), "_blank")}>IAI検索</button>
                <button className="primaryButton" onClick={() => window.open(makeSearchUrl(row, "panasonic"), "_blank")}>Panasonic検索</button>
                <button className="primaryButton" onClick={() => window.open(makeSearchUrl(row, "image"), "_blank")}>画像検索</button>
                {row.purchaseUrl && (
                  <button className="primaryButton" onClick={() => window.open(row.purchaseUrl, "_blank")}>購入URLを開く</button>
                )}
                <button className="deleteButton" onClick={() => removeItem("parts", row.id)}><Trash2 size={16} /> 削除</button>
              </div>
            </div>
          </div>
        ))}
      </>
    );
  }

  function renderCalendarModal() {
    if (!newCalendarEvent) return null;

    return (
      <div className="modalBackdrop">
        <div className="modalCard">
          <div className="header">
            <div>
              <h2>{editingCalendarEventId ? "✏️ 予定編集" : "📅 新しい予定"}</h2>
              <p>{newCalendarEvent.date} の予定を{editingCalendarEventId ? "編集" : "登録"}します。</p>
            </div>
            <button className="deleteButton" onClick={cancelNewCalendarEvent}><X size={16} /> 閉じる</button>
          </div>

          <div className="reportGrid">
            <label>日付<input type="date" value={newCalendarEvent.date || ""} onChange={(e) => setNewCalendarEvent({ ...newCalendarEvent, date: e.target.value })} /></label>
            <label>時間<input type="time" value={newCalendarEvent.time || ""} onChange={(e) => setNewCalendarEvent({ ...newCalendarEvent, time: e.target.value })} /></label>
            <label>区分
              <select value={newCalendarEvent.category || "定期保全"} onChange={(e) => setNewCalendarEvent({ ...newCalendarEvent, category: e.target.value })}>
                <option value="定期保全">定期保全</option>
                <option value="計画工事">計画工事</option>
                <option value="会議">会議</option>
                <option value="緊急">緊急</option>
              </select>
            </label>
            <label>重要度
              <select value={newCalendarEvent.importance || "通常"} onChange={(e) => setNewCalendarEvent({ ...newCalendarEvent, importance: e.target.value })}>
                <option value="通常">通常</option>
                <option value="重要">重要</option>
              </select>
            </label>
            <label>タイトル<input value={newCalendarEvent.title || ""} onChange={(e) => setNewCalendarEvent({ ...newCalendarEvent, title: e.target.value })} /></label>
            <label>担当者<input value={newCalendarEvent.owner || ""} onChange={(e) => setNewCalendarEvent({ ...newCalendarEvent, owner: e.target.value })} /></label>
          </div>

          <h3>内容</h3>
          <textarea value={newCalendarEvent.detail || ""} onChange={(e) => setNewCalendarEvent({ ...newCalendarEvent, detail: e.target.value })} />

          <h3>写真</h3>
          <input type="file" accept="image/*" onChange={(e) => handleDraftImageUpload(e, setNewCalendarEvent)} />
          {newCalendarEvent.image && <img src={newCalendarEvent.image} alt="" className="calendarPhoto" />}

          <div style={{ display: "flex", gap: "10px", marginTop: "18px" }}>
            <button className="primaryButton" onClick={saveNewCalendarEvent}><Save size={16} /> {editingCalendarEventId ? "更新" : "保存"}</button>
            <button className="deleteButton" onClick={cancelNewCalendarEvent}><X size={16} /> キャンセル</button>
          </div>
        </div>
      </div>
    );
  }

  function renderCalendar() {
    const getCategoryIcon = (category = "") => {
      if (category.includes("計画工事")) return "🏗️";
      if (category.includes("保全報告")) return "📝";
      if (category.includes("定期保全")) return "🔧";
      if (category.includes("緊急")) return "🔴";
      if (category.includes("会議")) return "👥";
      return "📌";
    };

    const summarizeDayEvents = (events = []) => {
      const summary = {};
      events.forEach((event) => {
        const category = event.category || "予定";
        summary[category] = (summary[category] || 0) + 1;
      });
      return Object.entries(summary).slice(0, 3);
    };

    const selectedEvents = unifiedCalendarEvents.filter((event) => event.date === selectedDate);

    return (
      <>
        <div className="header">
          <div>
            <h2>📅 カレンダー</h2>
            <p>月表示は「件数・区分」だけを見やすく表示し、詳細は下の予定一覧で確認できます。</p>
          </div>
          <button className="primaryButton" onClick={() => startNewCalendarEvent(selectedDate)}>
            <Plus size={16} /> 選択日の予定追加
          </button>
        </div>

        <div className="tableWrap">
          <div className="calendarTop">
            <button onClick={() => changeMonth(-1)}>＜ 前月</button>
            <h2>{calendarMonth.getFullYear()}年 {calendarMonth.getMonth() + 1}月</h2>
            <button onClick={() => changeMonth(1)}>翌月 ＞</button>
            <button onClick={() => {
              const now = todayText();
              setCalendarMonth(new Date());
              setSelectedDate(now);
            }}>今日</button>
          </div>

          <div className="calendarWeek">
            <div>日</div><div>月</div><div>火</div><div>水</div><div>木</div><div>金</div><div>土</div>
          </div>

          <div className="calendarGrid">
            {getCalendarDays().map((date, index) => {
              const dayEvents = date ? unifiedCalendarEvents.filter((event) => event.date === date) : [];
              const summaries = summarizeDayEvents(dayEvents);
              const firstImportant = dayEvents.find((event) => event.importance === "重要") || dayEvents[0];

              return (
                <div
                  key={index}
                  className={`calendarDay ${!date ? "emptyDay" : ""} ${date === selectedDate ? "selectedDay" : ""}`}
                  onClick={() => {
                    if (!date) return;
                    setSelectedDate(date);
                  }}
                >
                  {date && (
                    <>
                      <div className="calendarDayHeader">
                        <span className="calendarDayNumber">{Number(date.slice(8, 10))}</span>
                        {dayEvents.length > 0 && <span className="eventCount">{dayEvents.length}件</span>}
                      </div>

                      {dayEvents.length > 0 && (
                        <div className="calendarSummaryPills">
                          {summaries.map(([category, count]) => (
                            <span
                              key={category}
                              className={`calendarSummaryPill ${dayEvents.some((e) => e.category === category && e.importance === "重要") ? "urgentPill" : ""}`}
                              title={`${category}: ${count}件`}
                            >
                              {getCategoryIcon(category)} {count}
                            </span>
                          ))}
                        </div>
                      )}

                      {firstImportant && (
                        <span className="calendarMiniText" title={firstImportant.title || "予定"}>
                          {getCategoryIcon(firstImportant.category)} {firstImportant.time ? `${firstImportant.time} ` : ""}{firstImportant.title || "予定"}
                        </span>
                      )}
                    </>
                  )}
                </div>
              );
            })}
          </div>

          <div className="selectedEventsHeader">
            <div>
              <h3 style={{ margin: 0 }}>{selectedDate} の予定</h3>
              <p style={{ margin: "4px 0 0", color: "#64748b" }}>
                月カレンダーで選んだ日の詳細です。
              </p>
            </div>
            <button className="primaryButton" onClick={() => startNewCalendarEvent(selectedDate)}>
              <Plus size={16} /> この日に追加
            </button>
          </div>

          {selectedEvents.length === 0 && (
            <div className="calendarEditCard" style={{ marginTop: "12px" }}>
              <p>予定はありません。</p>
            </div>
          )}

          <div className="selectedEventCards">
            {selectedEvents.map((event) => (
              <div key={event.id} className="eventRow">
                <div className="eventRowTitle">
                  <b>{getCategoryIcon(event.category)} {event.importance === "重要" ? "【重要】" : ""}{event.title || "予定"}</b>
                </div>

                <div className="eventMetaLine">
                  {event.time && <span className="eventMetaBadge">⏰ {event.time}</span>}
                  <span className="eventMetaBadge">区分: {event.category || "-"}</span>
                  <span className="eventMetaBadge">担当: {event.owner || "-"}</span>
                </div>

                <div className="eventDetailText">{event.detail || "詳細なし"}</div>

                {event.image && <img src={event.image} alt="" className="calendarPhoto" />}

                <div style={{ display: "flex", gap: "8px", flexWrap: "wrap", marginTop: "12px" }}>
                  {event.page && event.page !== "calendar" && (
                    <button className="primaryButton" onClick={() => setPage(event.page)}>
                      関連画面を開く
                    </button>
                  )}
                  {event.deletable ? (
                    <>
                      <button className="primaryButton" onClick={() => startEditCalendarEvent(event)}>✏️ 編集</button>
                      <button className="deleteButton" onClick={() => removeItem("calendar", event.id)}><Trash2 size={16} /> 削除</button>
                    </>
                  ) : (
                    <span style={{ color: "#64748b", fontSize: "12px", alignSelf: "center" }}>自動連携データ</span>
                  )}
                </div>
              </div>
            ))}
          </div>
        </div>

        {renderCalendarModal()}
      </>
    );
  }

  function ReportViewCard({ row }) {
    const calc = calculateReport(row);
    const setRow = (field, value) => updateField("maintenanceReports", row.id, field, value);

    return (
      <div className="tableWrap" key={row.id} style={{ marginTop: "20px" }}>
        <div
          style={{
            border: "2px solid #0f172a",
            borderRadius: "16px",
            overflow: "hidden",
            background: "#fff",
            marginBottom: "14px",
          }}
        >
          <div style={{ display: "grid", gridTemplateColumns: "1fr 420px", borderBottom: "2px solid #0f172a" }}>
            <div style={{ padding: "16px", textAlign: "center" }}>
              <h2 style={{ margin: 0 }}>保全作業報告書</h2>
              <h3 style={{ margin: "8px 0 0" }}>{row.equipment || "設備名未入力"} / {row.lineName || "ライン未入力"}</h3>
              <p style={{ margin: "8px 0 0", color: "#64748b" }}>{row.phenomenon || "不具合現象未入力"}</p>
            </div>
            <div style={{ display: "grid", gridTemplateColumns: "repeat(4, 1fr)", borderLeft: "2px solid #0f172a" }}>
              {[
                ["DB入力", row.dbInputBy, row.dbInputDate],
                ["承認", row.approvedBy, row.approvedDate],
                ["点検", row.inspectedBy, row.inspectedDate],
                ["作成", row.createdBy || row.worker, row.reportCreatedDate || row.createdAt],
              ].map(([label, name, date]) => (
                <div key={label} style={{ borderRight: "1px solid #94a3b8", padding: "8px", minHeight: "78px" }}>
                  <strong>{label}</strong>
                  <div>{name || "—"}</div>
                  <small>{date || ""}</small>
                </div>
              ))}
            </div>
          </div>
          <div style={{ padding: "10px", background: reportStatusColor(row.approvalStatus), display: "flex", gap: "10px", flexWrap: "wrap", alignItems: "center" }}>
            <strong>状態：</strong>
            <select value={row.approvalStatus || "下書き"} onChange={(e) => setRow("approvalStatus", e.target.value)} style={{ maxWidth: "180px" }}>
              <option value="下書き">下書き</option>
              <option value="点検待ち">点検待ち</option>
              <option value="承認待ち">承認待ち</option>
              <option value="承認済み">承認済み</option>
              <option value="差戻し">差戻し</option>
              <option value="Excel取込">Excel取込</option>
            </select>
            <button className="deleteButton" onClick={() => removeItem("maintenanceReports", row.id)}><Trash2 size={16} /> 削除</button>
          </div>
        </div>

        <Section sectionKey="basic" title="📌 基本情報・設備情報">
          <div className="reportGrid">
            <label>作成日<input type="date" value={row.createdAt || ""} onChange={(e) => setRow("createdAt", e.target.value)} /></label>
            <label>保全分類<input value={row.maintenanceType || ""} onChange={(e) => setRow("maintenanceType", e.target.value)} /></label>
            <label>グループ名<input value={row.groupName || ""} onChange={(e) => setRow("groupName", e.target.value)} /></label>
            <label>ライン名<input value={row.lineName || ""} onChange={(e) => setRow("lineName", e.target.value)} /></label>
            <label>設備名<input value={row.equipment || ""} onChange={(e) => setRow("equipment", e.target.value)} /></label>
            <label>作業者<input value={row.worker || ""} onChange={(e) => setRow("worker", e.target.value)} /></label>
          </div>
        </Section>

        <Section sectionKey="time" title="⏱️ 時間・停止時間">
          <div className="reportGrid">
            <label>①不具合発生日時<input type="datetime-local" value={row.troubleDateTime || ""} onChange={(e) => setRow("troubleDateTime", e.target.value)} /></label>
            <label>②保全作業開始日時<input type="datetime-local" value={row.workStartDateTime || ""} onChange={(e) => setRow("workStartDateTime", e.target.value)} /></label>
            <label>③保全作業完了日時<input type="datetime-local" value={row.workEndDateTime || ""} onChange={(e) => setRow("workEndDateTime", e.target.value)} /></label>
            <label>④生産開始日時<input type="datetime-local" value={row.productionStartDateTime || ""} onChange={(e) => setRow("productionStartDateTime", e.target.value)} /></label>
            <label>⑤停止除外時間H<input type="number" value={row.stopExclusionHours ?? 0} onChange={(e) => setRow("stopExclusionHours", e.target.value)} /></label>
            <label>⑥機能低下(%)<input type="number" value={row.functionDownRate ?? 100} onChange={(e) => setRow("functionDownRate", e.target.value)} /></label>
            <label>⑦停止時間H<input readOnly value={calc.stopTimeHours} /></label>
          </div>
        </Section>

        <Section sectionKey="trouble" title="📝 不具合内容・処置">
          <h3>不具合現象</h3><textarea value={row.phenomenon || ""} onChange={(e) => setRow("phenomenon", e.target.value)} />
          <h3>不具合箇所</h3><textarea value={row.troublePoint || ""} onChange={(e) => setRow("troublePoint", e.target.value)} />
          <h3>処置内容</h3><textarea value={row.action || ""} onChange={(e) => setRow("action", e.target.value)} />
          <h3>リンク先</h3><input value={row.linkUrl || ""} onChange={(e) => setRow("linkUrl", e.target.value)} />
        </Section>

        <Section sectionKey="why" title="🔍 不具合原因・なぜなぜ分析">
          {[1, 2, 3, 4, 5].map((num) => (
            <label key={num}>なぜ{num}<textarea value={row[`why${num}`] || ""} onChange={(e) => setRow(`why${num}`, e.target.value)} /></label>
          ))}
        </Section>

        <Section sectionKey="prevention" title="🛠️ 再発防止・流出防止・変化点">
          <div className="reportGrid">
            <label>再発防止区分<input value={row.recurrenceCategory || ""} onChange={(e) => setRow("recurrenceCategory", e.target.value)} /></label>
            <label>変化点ランク<input value={row.changeRank || ""} onChange={(e) => setRow("changeRank", e.target.value)} /></label>
            <label>FP点検<input value={row.fpInspection || ""} onChange={(e) => setRow("fpInspection", e.target.value)} /></label>
          </div>
          <h3>再発防止・残工事</h3><textarea value={row.recurrencePrevention || ""} onChange={(e) => setRow("recurrencePrevention", e.target.value)} />
          <h3>流出防止</h3><textarea value={row.outflowPrevention || ""} onChange={(e) => setRow("outflowPrevention", e.target.value)} />
        </Section>

        <Section sectionKey="cost" title="💰 保全費用">
          <div className="reportGrid">
            <label>作業者数<input type="number" value={row.workerCount || 1} onChange={(e) => setRow("workerCount", e.target.value)} /></label>
            <label>時間単価<input type="number" value={row.laborRate || 3000} onChange={(e) => setRow("laborRate", e.target.value)} /></label>
            <label>保全工数H<input readOnly value={calc.laborHours} /></label>
            <label>労務費<input readOnly value={calc.laborCost.toLocaleString()} /></label>
            <label>部品費合計<input readOnly value={calc.partsCost.toLocaleString()} /></label>
            <label>保全費用合計<input readOnly value={calc.totalCost.toLocaleString()} /></label>
          </div>
          <h3>保全交換部品</h3>
          {[1, 2, 3].map((num) => (
            <div className="reportGrid" key={num}>
              <label>部品名{num}<input value={row[`partName${num}`] || ""} onChange={(e) => setRow(`partName${num}`, e.target.value)} /></label>
              <label>個数<input type="number" value={row[`partQty${num}`] || ""} onChange={(e) => setRow(`partQty${num}`, e.target.value)} /></label>
              <label>単価<input type="number" value={row[`partUnitPrice${num}`] || ""} onChange={(e) => setRow(`partUnitPrice${num}`, e.target.value)} /></label>
              <label>部品費<input readOnly value={(calc[`partAmount${num}`] || 0).toLocaleString()} /></label>
            </div>
          ))}
        </Section>

        <Section sectionKey="approval" title="✅ 確認・承認">
          <div className="reportGrid">
            <label>DB入力者<input value={row.dbInputBy || ""} onChange={(e) => setRow("dbInputBy", e.target.value)} /></label>
            <label>DB入力日<input type="date" value={row.dbInputDate || ""} onChange={(e) => setRow("dbInputDate", e.target.value)} /></label>
            <label>承認者<input value={row.approvedBy || ""} onChange={(e) => setRow("approvedBy", e.target.value)} /></label>
            <label>承認日<input type="date" value={row.approvedDate || ""} onChange={(e) => setRow("approvedDate", e.target.value)} /></label>
            <label>点検者<input value={row.inspectedBy || ""} onChange={(e) => setRow("inspectedBy", e.target.value)} /></label>
            <label>点検日<input type="date" value={row.inspectedDate || ""} onChange={(e) => setRow("inspectedDate", e.target.value)} /></label>
            <label>作成者<input value={row.createdBy || ""} onChange={(e) => setRow("createdBy", e.target.value)} /></label>
            <label>作成日<input type="date" value={row.reportCreatedDate || ""} onChange={(e) => setRow("reportCreatedDate", e.target.value)} /></label>
          </div>
        </Section>

        <Section sectionKey="other" title="📷 写真・備考">
          <input type="file" accept="image/*" onChange={(e) => handleImageUpload(e, "maintenanceReports", row.id)} />
          {row.image && <img src={row.image} alt="" className="calendarPhoto" />}
          <h3>備考</h3><textarea value={row.note || ""} onChange={(e) => setRow("note", e.target.value)} />
        </Section>
      </div>
    );
  }

  function renderReports() {
    return (
      <>
        <div className="header">
          <div>
            <h2>📝 保全修理報告書</h2>
            <p>Excel原紙の項目を残し、承認・費用計算・停止時間計算・カレンダー連携まで管理します。</p>
          </div>
          <button className="primaryButton" onClick={startNewReport}><Plus size={16} /> 新規作成</button>
        </div>

        <ReportDraftForm />

        <div className="tableWrap">
          <input
            value={reportSearch}
            onChange={(e) => setReportSearch(e.target.value)}
            placeholder="検索：設備名・ライン名・不具合現象・原因・処置内容・担当者・承認状態"
          />
        </div>

        {filteredReports.map((row) => <ReportViewCard key={row.id} row={row} />)}
      </>
    );
  }


  function renderPlannedWorks() {
    const statusOptions = ["計画中", "準備中", "実施中", "完了", "延期"];

    const statusBadgeStyle = (status = "計画中") => {
      if (status === "完了") return { background: "#dcfce7", color: "#166534", border: "1px solid #bbf7d0" };
      if (status === "実施中") return { background: "#dbeafe", color: "#1d4ed8", border: "1px solid #bfdbfe" };
      if (status === "準備中") return { background: "#fef3c7", color: "#92400e", border: "1px solid #fde68a" };
      if (status === "延期") return { background: "#fee2e2", color: "#b91c1c", border: "1px solid #fecaca" };
      return { background: "#f1f5f9", color: "#334155", border: "1px solid #e2e8f0" };
    };

    const progressPercent = (value) => Math.min(100, Math.max(0, Number(value || 0)));

    return (
      <>
        <div className="header">
          <div>
            <h2>🏗️ 計画工事</h2>
            <p>計画工事をカード形式で見やすく管理します。保存すると自動でカレンダーにも登録されます。</p>
          </div>

          <button className="primaryButton" onClick={startNewPlannedWork}>
            <Plus size={16} /> 工事追加
          </button>
        </div>

        {newPlannedWork && (
          <div className="tableWrap" style={{ border: "2px solid #2563eb" }}>
            <div className="header">
              <div>
                <h2>🏗️ 新規 計画工事</h2>
                <p>工事件名・設備・目的・内容を入力してください。</p>
              </div>

              <div style={{ display: "flex", gap: "10px", flexWrap: "wrap" }}>
                <button className="primaryButton" onClick={saveNewPlannedWork}>
                  <Save size={16} /> 保存
                </button>
                <button className="deleteButton" onClick={cancelNewPlannedWork}>
                  <X size={16} /> キャンセル
                </button>
              </div>
            </div>

            <div className="reportGrid">
              <label>開始日
                <input type="date" value={newPlannedWork.date || ""} onChange={(e) => setNewPlannedWork({ ...newPlannedWork, date: e.target.value })} />
              </label>

              <label>完了予定日
                <input type="date" value={newPlannedWork.endDate || ""} onChange={(e) => setNewPlannedWork({ ...newPlannedWork, endDate: e.target.value })} />
              </label>

              <label>工事件名
                <input value={newPlannedWork.title || ""} onChange={(e) => setNewPlannedWork({ ...newPlannedWork, title: e.target.value })} />
              </label>

              <label>設備名
                <input value={newPlannedWork.equipment || ""} onChange={(e) => setNewPlannedWork({ ...newPlannedWork, equipment: e.target.value })} />
              </label>

              <label>目的
                <input value={newPlannedWork.purpose || ""} onChange={(e) => setNewPlannedWork({ ...newPlannedWork, purpose: e.target.value })} />
              </label>

              <label>担当者
                <input value={newPlannedWork.owner || ""} onChange={(e) => setNewPlannedWork({ ...newPlannedWork, owner: e.target.value })} />
              </label>

              <label>進捗 %
                <input type="number" min="0" max="100" value={newPlannedWork.progress || 0} onChange={(e) => setNewPlannedWork({ ...newPlannedWork, progress: e.target.value })} />
              </label>

              <label>状態
                <select value={newPlannedWork.status || "計画中"} onChange={(e) => setNewPlannedWork({ ...newPlannedWork, status: e.target.value })}>
                  {statusOptions.map((status) => (
                    <option key={status} value={status}>{status}</option>
                  ))}
                </select>
              </label>
            </div>

            <h3>内容</h3>
            <textarea value={newPlannedWork.detail || ""} onChange={(e) => setNewPlannedWork({ ...newPlannedWork, detail: e.target.value })} />

            <h3>リスク</h3>
            <textarea value={newPlannedWork.risk || ""} onChange={(e) => setNewPlannedWork({ ...newPlannedWork, risk: e.target.value })} />

            <h3>備考</h3>
            <textarea value={newPlannedWork.note || ""} onChange={(e) => setNewPlannedWork({ ...newPlannedWork, note: e.target.value })} />
          </div>
        )}

        {plannedWorks.length === 0 && (
          <div className="tableWrap">
            <h3>計画工事はまだ登録されていません。</h3>
            <p>右上の「工事追加」から登録できます。</p>
          </div>
        )}

        <div style={{ display: "grid", gap: "18px" }}>
          {plannedWorks.map((row) => (
            <div key={row.id} className="tableWrap" style={{ padding: "24px" }}>
              <div style={{ display: "flex", justifyContent: "space-between", gap: "14px", flexWrap: "wrap", alignItems: "flex-start" }}>
                <div style={{ minWidth: 0, flex: "1 1 420px" }}>
                  <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", alignItems: "center", marginBottom: "10px" }}>
                    <span style={{ padding: "7px 12px", borderRadius: "999px", fontWeight: "900", ...statusBadgeStyle(row.status) }}>
                      {row.status || "計画中"}
                    </span>
                    <span style={{ padding: "7px 12px", borderRadius: "999px", fontWeight: "800", background: "#eff6ff", color: "#1d4ed8", border: "1px solid #bfdbfe" }}>
                      {row.date || "開始日未入力"} 〜 {row.endDate || "完了予定日未入力"}
                    </span>
                  </div>

                  <h2 style={{ margin: 0, fontSize: "30px", lineHeight: 1.25, wordBreak: "break-word" }}>
                    🏗️ {row.title || "工事件名なし"}
                  </h2>

                  <p style={{ margin: "10px 0 0", color: "#475569", fontSize: "17px", lineHeight: 1.7, whiteSpace: "pre-wrap" }}>
                    <b>設備：</b>{row.equipment || "-"}　/　<b>目的：</b>{row.purpose || "-"}　/　<b>担当：</b>{row.owner || "-"}
                  </p>
                </div>

                <div style={{ minWidth: "230px", flex: "0 1 260px" }}>
                  <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center", marginBottom: "8px" }}>
                    <strong>進捗</strong>
                    <strong style={{ color: "#2563eb" }}>{progressPercent(row.progress)}%</strong>
                  </div>
                  <div style={{ height: "14px", background: "#dbeafe", borderRadius: "999px", overflow: "hidden" }}>
                    <div style={{ width: `${progressPercent(row.progress)}%`, height: "100%", background: "#2563eb", borderRadius: "999px" }} />
                  </div>
                </div>
              </div>

              <div className="reportGrid" style={{ marginTop: "20px" }}>
                <label>開始日
                  <input type="date" value={row.date || ""} onChange={(e) => updateField("plannedWorks", row.id, "date", e.target.value)} />
                </label>

                <label>完了予定日
                  <input type="date" value={row.endDate || ""} onChange={(e) => updateField("plannedWorks", row.id, "endDate", e.target.value)} />
                </label>

                <label>工事件名
                  <input value={row.title || ""} onChange={(e) => updateField("plannedWorks", row.id, "title", e.target.value)} />
                </label>

                <label>設備名
                  <input value={row.equipment || ""} onChange={(e) => updateField("plannedWorks", row.id, "equipment", e.target.value)} />
                </label>

                <label>目的
                  <input value={row.purpose || ""} onChange={(e) => updateField("plannedWorks", row.id, "purpose", e.target.value)} />
                </label>

                <label>担当者
                  <input value={row.owner || ""} onChange={(e) => updateField("plannedWorks", row.id, "owner", e.target.value)} />
                </label>

                <label>進捗 %
                  <input type="number" min="0" max="100" value={row.progress || 0} onChange={(e) => updateField("plannedWorks", row.id, "progress", e.target.value)} />
                </label>

                <label>状態
                  <select value={row.status || "計画中"} onChange={(e) => updateField("plannedWorks", row.id, "status", e.target.value)}>
                    {statusOptions.map((status) => (
                      <option key={status} value={status}>{status}</option>
                    ))}
                  </select>
                </label>
              </div>

              <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: "14px", marginTop: "14px" }}>
                <label style={{ fontWeight: "800" }}>内容
                  <textarea style={{ minHeight: "120px" }} value={row.detail || ""} onChange={(e) => updateField("plannedWorks", row.id, "detail", e.target.value)} />
                </label>

                <label style={{ fontWeight: "800" }}>リスク
                  <textarea style={{ minHeight: "120px" }} value={row.risk || ""} onChange={(e) => updateField("plannedWorks", row.id, "risk", e.target.value)} />
                </label>
              </div>

              <h3>備考</h3>
              <textarea value={row.note || ""} onChange={(e) => updateField("plannedWorks", row.id, "note", e.target.value)} />

              <div style={{ display: "flex", gap: "10px", flexWrap: "wrap", marginTop: "16px" }}>
                <button className="primaryButton" onClick={() => setPage("calendar")}>
                  📅 カレンダー確認
                </button>

                <button className="deleteButton" onClick={() => removeItem("plannedWorks", row.id)}>
                  <Trash2 size={16} /> 削除
                </button>
              </div>
            </div>
          ))}
        </div>
      </>
    );
  }

  function renderAiSearch() {
    return (
      <div className="tableWrap">
        <h2>🔍 AI検索</h2>
        <p>保全報告書・定期保全・予備品管理・カレンダー・計画工事から関連情報をまとめて検索します。</p>

        <input
          value={aiSearch}
          onChange={(e) => {
            setAiSearch(e.target.value);
            setGlobalSearch(e.target.value);
          }}
          placeholder="例：ロードセル 78-60 異常停止 在庫不足"
          style={{ margin: "16px 0" }}
        />

        <button className="primaryButton" onClick={makeAiAnswer}><Bot size={16} /> AI分析</button>

        <div className="calendarEditCard" style={{ marginTop: "20px" }}>
          <h3>AI自動報告書作成</h3>
          <p>短く入力すると、保全作業報告書を自動で作成します。</p>
          <textarea value={autoReportInput} onChange={(e) => setAutoReportInput(e.target.value)} placeholder="例：78-60 ロードセル異常 荷重確認 配線確認" />
          <button className="primaryButton" onClick={createAutoReport}>報告書を自動作成</button>
        </div>

        {aiLevel && (
          <div className={`calendarEditCard ${aiLevel.includes("緊急") ? "aiHigh" : aiLevel.includes("注意") ? "aiMiddle" : "aiLow"}`} style={{ marginTop: "20px" }}>
            <h3>{aiLevel}</h3>
          </div>
        )}

        {aiAnswer && <div className="calendarEditCard" style={{ marginTop: "20px", whiteSpace: "pre-line" }}>{aiAnswer}</div>}

        <h3 style={{ marginTop: "24px" }}>関連データ一覧：{aiResults.length}件</h3>
        {aiResults.length === 0 && aiSearch && <p>該当する履歴が見つかりません。</p>}

        {aiResults.map((item, index) => (
          <div key={index} className="calendarEditCard" style={{ cursor: "pointer" }} onClick={() => setPage(item.page)}>
            <b>{item.category} / {item.date}</b>
            <h3>{item.title}</h3>
            <p>{item.text || "-"}</p>
          </div>
        ))}
      </div>
    );
  }


  function renderAnalytics() {
    const baseDate = new Date(`${analyticsBaseDate || todayText()}T00:00:00`);

    function startOfWeek(date) {
      const d = new Date(date);
      d.setHours(0, 0, 0, 0);
      const day = d.getDay();
      const diff = day === 0 ? -6 : 1 - day;
      d.setDate(d.getDate() + diff);
      return d;
    }

    function endOfWeek(date) {
      const d = startOfWeek(date);
      d.setDate(d.getDate() + 6);
      d.setHours(23, 59, 59, 999);
      return d;
    }

    function getAnalyticsRange() {
      const start = new Date(baseDate);
      const end = new Date(baseDate);
      start.setHours(0, 0, 0, 0);
      end.setHours(23, 59, 59, 999);

      if (analyticsPeriod === "week") {
        return { start: startOfWeek(baseDate), end: endOfWeek(baseDate), label: `${startOfWeek(baseDate).toISOString().slice(0, 10)} 〜 ${endOfWeek(baseDate).toISOString().slice(0, 10)}` };
      }

      if (analyticsPeriod === "month") {
        const s = new Date(baseDate.getFullYear(), baseDate.getMonth(), 1);
        const e = new Date(baseDate.getFullYear(), baseDate.getMonth() + 1, 0, 23, 59, 59, 999);
        return { start: s, end: e, label: `${baseDate.getFullYear()}年${String(baseDate.getMonth() + 1).padStart(2, "0")}月` };
      }

      if (analyticsPeriod === "year") {
        const s = new Date(baseDate.getFullYear(), 0, 1);
        const e = new Date(baseDate.getFullYear(), 11, 31, 23, 59, 59, 999);
        return { start: s, end: e, label: `${baseDate.getFullYear()}年` };
      }

      return { start, end, label: analyticsBaseDate || todayText() };
    }

    function shiftAnalyticsRange(amount) {
      const d = new Date(baseDate);
      if (analyticsPeriod === "day") d.setDate(d.getDate() + amount);
      if (analyticsPeriod === "week") d.setDate(d.getDate() + amount * 7);
      if (analyticsPeriod === "month") d.setMonth(d.getMonth() + amount);
      if (analyticsPeriod === "year") d.setFullYear(d.getFullYear() + amount);
      setAnalyticsBaseDate(toLocalDateText(d));
    }

    function getReportDate(report) {
      return normalizeDateOnly(report.createdAt || report.troubleDateTime || report.workStartDateTime || report.reportCreatedDate);
    }

    const analyticsRange = getAnalyticsRange();
    const sourceReports = reports.filter((r) => {
      const dateText = getReportDate(r);
      if (!dateText) return false;
      const d = new Date(`${dateText}T12:00:00`);
      return d >= analyticsRange.start && d <= analyticsRange.end;
    });

    function workDaysBetween(start, end) {
      const d = new Date(start);
      d.setHours(0, 0, 0, 0);
      const last = new Date(end);
      last.setHours(0, 0, 0, 0);
      let count = 0;
      while (d <= last) {
        const day = d.getDay();
        if (day !== 0 && day !== 6) count += 1;
        d.setDate(d.getDate() + 1);
      }
      return Math.max(1, count);
    }

    function safeText(...values) {
      return values.filter(Boolean).join(" ").toLowerCase();
    }

    function classifyReason(r) {
      const text = safeText(
        r.phenomenon,
        r.troublePoint,
        r.cause,
        r.why1,
        r.why2,
        r.why3,
        r.action,
        r.replacedPart,
        r.note
      );

      const rules = [
        { name: "センサー異常", words: ["センサー", "sensor", "近接", "検出", "光電", "リミット", "e2", "pz", "fu-"] },
        { name: "ロードセル異常", words: ["ロードセル", "loadcell", "荷重", "重量"] },
        { name: "エア漏れ・空圧", words: ["エア", "air", "漏れ", "空圧", "圧力", "レギュレータ"] },
        { name: "シリンダ不良", words: ["シリンダ", "cylinder", "ロッド", "ストローク"] },
        { name: "電気故障", words: ["電気", "配線", "断線", "接触", "ブレーカ", "ヒューズ", "リレー", "電源", "端子"] },
        { name: "モーター・サーボ", words: ["モーター", "motor", "サーボ", "servo", "インバータ", "ドライバ"] },
        { name: "ボルト破損・緩み", words: ["ボルト", "ねじ", "ネジ", "緩み", "折損", "破断"] },
        { name: "部品破損・摩耗", words: ["破損", "摩耗", "割れ", "欠け", "曲がり", "損傷", "劣化"] },
        { name: "給油・潤滑不足", words: ["給油", "グリス", "潤滑", "油", "ボールねじ"] },
        { name: "汚れ・清掃不足", words: ["汚れ", "清掃", "ゴミ", "粉", "異物", "詰まり"] },
        { name: "位置ズレ・調整", words: ["位置", "ズレ", "ずれ", "調整", "芯", "高さ", "タイミング"] },
        { name: "搬送・排出不良", words: ["搬送", "排出", "フィーダ", "詰まり", "シュート", "ワーク", "供給"] },
        { name: "治具・金型", words: ["治具", "金型", "型", "プレート", "ホルダー", "ガイド"] },
      ];

      const hit = rules.find((rule) => rule.words.some((word) => text.includes(word)));
      return hit ? hit.name : "その他・未分類";
    }

    function pickProblemTitle(r) {
      return r.troublePoint || r.phenomenon || r.replacedPart || r.action || r.note || "内容未入力";
    }

    const workDays = workDaysBetween(analyticsRange.start, analyticsRange.end);
    const workingHoursPerMachine = workDays * 16;
    const shiftHours = 8;
    const twoShiftHours = 16;

    const analyzedReports = sourceReports.map((r) => {
      const calc = calculateReport(r);
      const equipment = r.equipment || r.lineName || "設備名なし";
      const line = r.lineName || r.groupName || "ライン未入力";
      const reason = classifyReason(r);
      const problemTitle = pickProblemTitle(r);
      const repairHours = hoursBetween(r.workStartDateTime, r.workEndDateTime);
      const stopHours = Number(calc.stopTimeHours || r.stopTime || 0) || 0;
      const date = r.createdAt || String(r.troubleDateTime || r.workStartDateTime || "").slice(0, 10);
      const month = date ? String(date).slice(0, 7) : "日付なし";

      return {
        ...r,
        equipment,
        line,
        reason,
        problemTitle,
        date,
        month,
        stopHours,
        repairHours,
        laborHours: Number(calc.laborHours || 0),
        laborCost: Number(calc.laborCost || 0),
        partsCost: Number(calc.partsCost || 0),
        totalCost: Number(calc.totalCost || 0),
      };
    });

    function groupStats(keyGetter) {
      const map = {};
      analyzedReports.forEach((r) => {
        const key = keyGetter(r) || "未入力";
        if (!map[key]) {
          map[key] = {
            key,
            count: 0,
            stopHours: 0,
            repairHours: 0,
            laborHours: 0,
            totalCost: 0,
            latest: "",
            machines: {},
            reasons: {},
            samples: [],
          };
        }
        map[key].count += 1;
        map[key].stopHours += Number(r.stopHours || 0);
        map[key].repairHours += Number(r.repairHours || 0);
        map[key].laborHours += Number(r.laborHours || 0);
        map[key].totalCost += Number(r.totalCost || 0);
        map[key].machines[r.equipment] = (map[key].machines[r.equipment] || 0) + 1;
        map[key].reasons[r.reason] = (map[key].reasons[r.reason] || 0) + 1;
        if (map[key].samples.length < 3) map[key].samples.push(r.problemTitle);
        if (r.date && r.date > map[key].latest) map[key].latest = r.date;
      });

      return Object.values(map).map((item) => ({
        ...item,
        stopHours: Number(item.stopHours.toFixed(2)),
        repairHours: Number(item.repairHours.toFixed(2)),
        laborHours: Number(item.laborHours.toFixed(2)),
        avgRepairHours: Number((item.repairHours / Math.max(1, item.count)).toFixed(2)),
        avgStopHours: Number((item.stopHours / Math.max(1, item.count)).toFixed(2)),
        lostPercent: Number(((item.stopHours / workingHoursPerMachine) * 100).toFixed(1)),
        mainMachine: Object.entries(item.machines).sort((a, b) => b[1] - a[1])[0]?.[0] || "-",
        mainReason: Object.entries(item.reasons).sort((a, b) => b[1] - a[1])[0]?.[0] || "-",
      }));
    }

    const machineStats = groupStats((r) => r.equipment).sort((a, b) => b.stopHours - a.stopHours || b.count - a.count);
    const reasonStats = groupStats((r) => r.reason).sort((a, b) => b.stopHours - a.stopHours || b.count - a.count);
    const problemStats = groupStats((r) => r.problemTitle).sort((a, b) => b.count - a.count || b.stopHours - a.stopHours);
    const partStats = groupStats((r) => r.replacedPart || r.partName1 || r.partNo || "交換部品未入力")
      .filter((x) => x.key !== "交換部品未入力")
      .sort((a, b) => b.count - a.count || b.totalCost - a.totalCost);
    const lineStats = groupStats((r) => r.line).sort((a, b) => b.stopHours - a.stopHours || b.count - a.count);
    const monthStats = groupStats((r) => r.month).sort((a, b) => String(a.key).localeCompare(String(b.key)));

    const machineReasonStats = groupStats((r) => `${r.equipment} × ${r.reason}`)
      .map((item) => {
        const [machine, reason] = item.key.split(" × ");
        return { ...item, machine, reason };
      })
      .sort((a, b) => b.stopHours - a.stopHours || b.count - a.count);

    const totalStopHours = analyzedReports.reduce((sum, r) => sum + Number(r.stopHours || 0), 0);
    const totalRepairHours = analyzedReports.reduce((sum, r) => sum + Number(r.repairHours || 0), 0);
    const totalCost = analyzedReports.reduce((sum, r) => sum + Number(r.totalCost || 0), 0);
    const totalPartsCost = analyzedReports.reduce((sum, r) => sum + Number(r.partsCost || 0), 0);
    const totalLaborCost = analyzedReports.reduce((sum, r) => sum + Number(r.laborCost || 0), 0);
    const stoppedMachines = new Set(analyzedReports.filter((r) => Number(r.stopHours || 0) > 0).map((r) => r.equipment)).size;
    const avgMttr = totalRepairHours / Math.max(1, analyzedReports.length);

    const maxStop = Math.max(1, ...machineStats.map((m) => m.stopHours));
    const maxReasonStop = Math.max(1, ...reasonStats.map((m) => m.stopHours));
    const maxReasonCount = Math.max(1, ...reasonStats.map((m) => m.count));
    const maxProblem = Math.max(1, ...problemStats.map((m) => m.count));
    const maxCost = Math.max(1, ...machineStats.map((m) => m.totalCost));

    const urgentReports = [...analyzedReports]
      .sort((a, b) => Number(b.stopHours || 0) - Number(a.stopHours || 0) || Number(b.repairHours || 0) - Number(a.repairHours || 0))
      .slice(0, 10);

    const formatHours = (value) => `${Number(value || 0).toFixed(1)}H`;
    const formatMoney = (value) => `¥${Math.round(Number(value || 0)).toLocaleString()}`;

    function BarRow({ label, value, max, sub, danger }) {
      const numeric = typeof value === "number" ? value : Number(String(value).replace(/[^0-9.-]/g, ""));
      const rawPercent = Number(((Number(numeric || 0) / Math.max(1, max)) * 100).toFixed(1));
      const width = Math.min(100, Math.max(Number(numeric || 0) > 0 ? 3 : 0, rawPercent));
      const isCountValue = String(value).includes("件") || String(value).includes("回");
      const valueText = isCountValue
        ? `${value} / ${rawPercent}%`
        : typeof value === "number" ? value : value;

      return (
        <div className="calendarEditCard" style={{ marginTop: "10px" }}>
          <div style={{ display: "flex", justifyContent: "space-between", gap: "10px", alignItems: "center" }}>
            <div style={{ minWidth: 0 }}>
              <h3 style={{ margin: 0, wordBreak: "break-word" }}>{label}</h3>
              <p style={{ margin: "4px 0", color: "#64748b", whiteSpace: "pre-wrap" }}>
                {sub}{isCountValue ? ` / 最大${max}を100%として比較` : ""}
              </p>
            </div>
            <strong style={{ fontSize: "22px", color: danger ? "#dc2626" : "#2563eb", whiteSpace: "nowrap" }}>{valueText}</strong>
          </div>
          <div style={{ height: "12px", background: "#e2e8f0", borderRadius: "999px", overflow: "hidden", marginTop: "10px" }}>
            <div style={{ width: `${width}%`, height: "100%", background: danger ? "#ef4444" : "#2563eb" }} />
          </div>
        </div>
      );
    }

    function CompareRow({ label, stopHours, repairHours, count, countMax = 1 }) {
      const percent = (value, base) => Number(((Number(value || 0) / Math.max(1, base)) * 100).toFixed(1));
      const visualWidth = (value, base) => Math.min(100, Math.max(Number(value || 0) > 0 ? 3 : 0, (Number(value || 0) / Math.max(1, base)) * 100));
      const countPercent = Number(((Number(count || 0) / Math.max(1, countMax)) * 100).toFixed(1));
      const countWidth = Math.min(100, Math.max(Number(count || 0) > 0 ? 3 : 0, countPercent));

      function CompareBar({ title, value, base, color, bg, unit = "H" }) {
        const p = percent(value, base);
        const w = visualWidth(value, base);
        return (
          <>
            <b style={{ whiteSpace: "normal", lineHeight: 1.35 }}>{title}</b>
            <div style={{ height: "16px", background: bg, borderRadius: "999px", overflow: "hidden" }}>
              <div style={{ width: `${w}%`, height: "100%", background: color, borderRadius: "999px" }} />
            </div>
            <strong style={{ whiteSpace: "nowrap" }}>{Number(value || 0).toFixed(1)}{unit} / {p}%</strong>
          </>
        );
      }

      return (
        <div className="calendarEditCard" style={{ marginTop: "12px", padding: "18px" }}>
          <h3 style={{ marginTop: 0, wordBreak: "break-word" }}>{label}</h3>
          <p style={{ margin: "0 0 14px", color: "#64748b" }}>
            停止・修理時間を、1直（8時間）と2直（16時間）の基準で比較表示しています。発生件数は全設備の最大件数を100%として比較しています。
          </p>
          <div className="compareGraphGrid" style={{ display: "grid", gridTemplateColumns: "280px 1fr 130px", gap: "12px", alignItems: "center" }}>
            <CompareBar title="🔴 停止時間（1直 8H基準）" value={stopHours} base={shiftHours} color="#ef4444" bg="#fee2e2" />
            <CompareBar title="🔴 停止時間（2直 16H基準）" value={stopHours} base={twoShiftHours} color="#dc2626" bg="#ffe4e6" />
            <CompareBar title="🟡 修理時間（1直 8H基準）" value={repairHours} base={shiftHours} color="#f59e0b" bg="#fef3c7" />
            <CompareBar title="🟡 修理時間（2直 16H基準）" value={repairHours} base={twoShiftHours} color="#d97706" bg="#ffedd5" />

            <b style={{ whiteSpace: "normal", lineHeight: 1.35 }}>🔵 発生件数（最大件数基準：最大{countMax}件 = 100%）</b>
            <div style={{ height: "16px", background: "#dbeafe", borderRadius: "999px", overflow: "hidden" }}>
              <div style={{ width: `${countWidth}%`, height: "100%", background: "#2563eb", borderRadius: "999px" }} />
            </div>
            <strong style={{ whiteSpace: "nowrap" }}>{count}件 / {countPercent}%</strong>
          </div>
        </div>
      );
    }

    return (
      <>
        <div className="header">
          <div>
            <h2>📊 故障・停止時間 詳細分析ダッシュボード</h2>
            <p>機械別だけでなく、故障理由・交換部品・ライン・停止時間・修理時間・費用を分けて比較します。</p>
          </div>
        </div>

        <div className="tableWrap" style={{ marginBottom: "18px" }}>
          <h3>📌 集計条件</h3>
          <p>
            日・週・月・年を切り替えて、停止時間・故障理由・費用・件数を比較できます。勤務時間は
            <strong> 1直8H・2直16H </strong>で比較し、日別ロスは2直合計16Hを100%として計算しています。
          </p>

          <div
            style={{
              display: "flex",
              gap: "10px",
              flexWrap: "wrap",
              alignItems: "center",
              marginBottom: "16px",
            }}
          >
            <button className="primaryButton" onClick={() => shiftAnalyticsRange(-1)}>← 前</button>

            <select
              value={analyticsPeriod}
              onChange={(e) => setAnalyticsPeriod(e.target.value)}
              style={{ maxWidth: "160px", fontWeight: "bold" }}
            >
              <option value="day">日別</option>
              <option value="week">週別</option>
              <option value="month">月別</option>
              <option value="year">年別</option>
            </select>

            <input
              type="date"
              value={analyticsBaseDate}
              onChange={(e) => setAnalyticsBaseDate(e.target.value)}
              style={{ maxWidth: "190px" }}
            />

            <button className="primaryButton" onClick={() => setAnalyticsBaseDate(todayText())}>今日</button>
            <button className="primaryButton" onClick={() => shiftAnalyticsRange(1)}>次 →</button>

            <div
              style={{
                padding: "12px 16px",
                borderRadius: "16px",
                background: "#eff6ff",
                color: "#1d4ed8",
                fontWeight: "900",
              }}
            >
              表示期間：{analyticsRange.label}
            </div>
          </div>

          <div className="cards">
            <div className="card"><span>対象報告書</span><strong>{sourceReports.length}</strong></div>
            <div className="card red"><span>停止時間合計</span><strong>{formatHours(totalStopHours)}</strong></div>
            <div className="card yellow"><span>修理時間合計</span><strong>{formatHours(totalRepairHours)}</strong></div>
            <div className="card"><span>平均修理時間 MTTR</span><strong>{formatHours(avgMttr)}</strong></div>
            <div className="card"><span>停止設備数</span><strong>{stoppedMachines}</strong></div>
            <div className="card"><span>1台あたり稼働予定</span><strong>{workingHoursPerMachine}H</strong><small>2直×8H×稼働日</small></div>
            <div className="card red"><span>総費用</span><strong>{formatMoney(totalCost)}</strong></div>
            <div className="card"><span>部品費 / 労務費</span><strong>{formatMoney(totalPartsCost)} / {formatMoney(totalLaborCost)}</strong></div>
          </div>
        </div>

        <div className="tableWrap" style={{ marginBottom: "18px" }}>
          <h3>📈 比較グラフ：機械別 停止時間・修理時間・件数</h3>
          <p>赤は停止時間、黄色は修理時間です。各時間は「1直8H基準」と「2直16H基準」で表示します。青は発生件数で、全設備の最大件数を100%として比較します。</p>
          {machineStats.slice(0, 10).map((m) => (
            <CompareRow key={m.key} label={m.key} stopHours={m.stopHours} repairHours={m.repairHours} count={m.count} countMax={Math.max(1, ...machineStats.map((x) => x.count))} />
          ))}
        </div>

        <div className="tableWrap" style={{ marginBottom: "18px" }}>
          <h3>🔥 故障理由別 TOP10</h3>
          <p>ここが一番大事です。同じ理由で何度も止まっているものを優先して対策します。</p>
          {reasonStats.slice(0, 10).map((m) => (
            <BarRow
              key={m.key}
              label={m.key}
              value={formatHours(m.stopHours)}
              max={maxReasonStop}
              danger={m.stopHours > 0}
              sub={`件数: ${m.count}件 / 主な設備: ${m.mainMachine} / 平均停止: ${formatHours(m.avgStopHours)} / 平均修理: ${formatHours(m.avgRepairHours)} / 費用: ${formatMoney(m.totalCost)}\n例: ${m.samples.join(" / ")}`}
            />
          ))}
        </div>

        <div className="tableWrap" style={{ marginBottom: "18px" }}>
          <h3>📊 故障理由 件数ランキング</h3>
          <p>件数が多い理由は、標準作業・点検周期・予備品の見直し対象です。</p>
          {reasonStats.slice(0, 10).map((m) => (
            <BarRow
              key={m.key}
              label={m.key}
              value={`${m.count}件`}
              max={maxReasonCount}
              sub={`停止時間: ${formatHours(m.stopHours)} / 主な設備: ${m.mainMachine}`}
            />
          ))}
        </div>

        <div className="tableWrap" style={{ marginBottom: "18px" }}>
          <h3>🚨 設備 × 故障理由 TOP15</h3>
          <p>どの設備で、どの理由が多いかを分けて表示します。改善テーマを決める時に一番使いやすい表です。</p>
          {machineReasonStats.slice(0, 15).map((m) => (
            <CompareRow
              key={m.key}
              label={`${m.machine} / ${m.reason}`}
              stopHours={m.stopHours}
              repairHours={m.repairHours}
              count={m.count}
              countMax={Math.max(1, ...machineReasonStats.map((x) => x.count))}
            />
          ))}
        </div>

        <div className="tableWrap" style={{ marginBottom: "18px" }}>
          <h3>🔩 交換部品 TOP10</h3>
          <p>同じ部品が多く交換されている場合、在庫数・交換周期・メーカー・使用条件を見直します。</p>
          {partStats.slice(0, 10).map((m) => (
            <BarRow
              key={m.key}
              label={m.key}
              value={`${m.count}回`}
              max={Math.max(1, ...partStats.map((x) => x.count))}
              sub={`主な設備: ${m.mainMachine} / 停止時間: ${formatHours(m.stopHours)} / 費用: ${formatMoney(m.totalCost)}`}
            />
          ))}
        </div>

        <div className="tableWrap" style={{ marginBottom: "18px" }}>
          <h3>🏭 ライン・工程別 ロス</h3>
          <p>どのライン・工程で時間を失っているかを確認できます。</p>
          {lineStats.slice(0, 10).map((m) => (
            <BarRow
              key={m.key}
              label={m.key}
              value={formatHours(m.stopHours)}
              max={Math.max(1, ...lineStats.map((x) => x.stopHours))}
              danger={m.stopHours > 0}
              sub={`件数: ${m.count}件 / 修理時間: ${formatHours(m.repairHours)} / 主な理由: ${m.mainReason}`}
            />
          ))}
        </div>

        <div className="tableWrap" style={{ marginBottom: "18px" }}>
          <h3>💰 費用 TOP10</h3>
          <p>お金が多くかかっている設備です。部品費と労務費の改善対象になります。</p>
          {machineStats.slice().sort((a, b) => b.totalCost - a.totalCost).slice(0, 10).map((m) => (
            <BarRow
              key={m.key}
              label={m.key}
              value={formatMoney(m.totalCost)}
              max={maxCost}
              sub={`故障回数: ${m.count}件 / 停止時間: ${formatHours(m.stopHours)} / 修理時間: ${formatHours(m.repairHours)} / 主な理由: ${m.mainReason}`}
            />
          ))}
        </div>

        <div className="tableWrap" style={{ marginBottom: "18px" }}>
          <h3>📅 月別トレンド</h3>
          <p>月ごとの停止時間・修理時間・件数を見て、問題が増えているか確認します。</p>
          {monthStats.map((m) => (
            <CompareRow key={m.key} label={m.key} stopHours={m.stopHours} repairHours={m.repairHours} count={m.count} countMax={Math.max(1, ...monthStats.map((x) => x.count))} />
          ))}
        </div>

        <div className="tableWrap">
          <h3>🧾 停止時間が大きい報告書 TOP10</h3>
          {urgentReports.map((r, index) => (
            <div key={r.id || index} className="calendarEditCard" style={{ cursor: "pointer" }} onClick={() => setPage("report")}>
              <b>{r.date || "日付なし"}</b>
              <h3>{r.equipment || "設備名なし"}</h3>
              <p><b>故障理由：</b>{r.reason}</p>
              <p><b>内容：</b>{r.phenomenon || r.troublePoint || r.action || "内容未入力"}</p>
              <div className="cards">
                <div className="card red"><span>停止時間</span><strong>{formatHours(r.stopHours)}</strong></div>
                <div className="card yellow"><span>修理時間</span><strong>{formatHours(r.repairHours)}</strong></div>
                <div className="card"><span>費用</span><strong>{formatMoney(r.totalCost)}</strong></div>
                <div className="card"><span>交換部品</span><strong>{r.replacedPart || "-"}</strong></div>
              </div>
            </div>
          ))}
        </div>
      </>
    );
  }
  function renderCurrentPage() {
    if (page === "home") return renderHome();
    if (page === "ai") return renderAiSearch();
    if (page === "report") return renderReports();
    if (page === "maintenance") return renderMaintenance();
    if (page === "spare") return renderSpareParts();
    if (page === "calendar") return renderCalendar();
    if (page === "analytics") return renderAnalytics();
    if (page === "work") return renderPlannedWorks();
    return renderHome();
  }

  const menuItems = [
    { key: "home", label: "ホーム", icon: <Home size={16} /> },
    { key: "ai", label: "AI検索", icon: <Search size={16} /> },
    { key: "report", label: "保全報告書", icon: <FileText size={16} /> },
    { key: "maintenance", label: "定期保全", icon: <Wrench size={16} /> },
    { key: "spare", label: "予備品管理", icon: <Package size={16} /> },
    { key: "calendar", label: "カレンダー", icon: <CalendarDays size={16} /> },
    { key: "analytics", label: "分析", icon: <Bot size={16} /> },
    { key: "work", label: "計画工事", icon: <Hammer size={16} /> },
  ];

return (
  <div className="page">
    <style>{PROFESSIONAL_RESPONSIVE_CSS}</style>
    <div className="container">

      <div className="tabs">
        {menuItems.map((item) => (
          <button
            key={item.key}
            className={page === item.key ? "active" : ""}
            onClick={() => setPage(item.key)}
          >
            {item.icon}
            {item.label}
          </button>
        ))}
      </div>

      {page !== "home" && renderGlobalSearchBox()}

      {renderCurrentPage()}

    </div>
  </div>
);
}